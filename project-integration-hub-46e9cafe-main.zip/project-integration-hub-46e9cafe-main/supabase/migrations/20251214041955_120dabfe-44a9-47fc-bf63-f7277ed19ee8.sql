-- Insert admin role for user ____YTBredXD
INSERT INTO public.user_roles (user_id, role)
VALUES ('98fe9db3-3d76-433e-8b8e-14960b42c4bd', 'admin')
ON CONFLICT (user_id, role) DO NOTHING;