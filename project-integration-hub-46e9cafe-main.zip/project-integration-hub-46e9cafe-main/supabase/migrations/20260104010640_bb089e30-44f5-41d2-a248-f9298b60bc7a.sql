-- Fix DM Channel Access Control Bypass Risk
-- Using regex with anchors to properly validate DM channel IDs

-- Drop existing vulnerable policies on messages table
DROP POLICY IF EXISTS "Users can view messages in accessible channels" ON public.messages;
DROP POLICY IF EXISTS "Users can only message accessible channels" ON public.messages;

-- Create helper function to validate DM channel access
CREATE OR REPLACE FUNCTION public.is_dm_participant(_channel_id text, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    _channel_id LIKE 'dm-%' AND (
      -- User is the first participant (position after 'dm-')
      _channel_id ~ ('^dm-' || _user_id::text || '-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$')
      OR
      -- User is the second participant (position at end)
      _channel_id ~ ('^dm-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}-' || _user_id::text || '$')
    )
$$;

-- Recreate secure SELECT policy for messages
CREATE POLICY "Users can view messages in accessible channels" 
ON public.messages 
FOR SELECT 
USING (
  -- DM messages: user must be a participant (using secure regex validation)
  (is_dm_participant(channel_id, auth.uid()))
  OR
  -- Public channels: anyone can view
  (EXISTS (
    SELECT 1 FROM channels
    WHERE channels.id::text = messages.channel_id 
    AND channels.is_private = false
  ))
  OR
  -- Private channels: must be a member
  (EXISTS (
    SELECT 1 FROM channels c
    JOIN channel_members cm ON c.id = cm.channel_id
    WHERE c.id::text = messages.channel_id 
    AND c.is_private = true 
    AND cm.user_id = auth.uid()
  ))
  OR
  -- Channel creator can always view
  (EXISTS (
    SELECT 1 FROM channels
    WHERE channels.id::text = messages.channel_id 
    AND channels.created_by = auth.uid()
  ))
);

-- Recreate secure INSERT policy for messages
CREATE POLICY "Users can only message accessible channels" 
ON public.messages 
FOR INSERT 
WITH CHECK (
  auth.uid() = user_id 
  AND (
    -- DM messages: user must be a participant (secure regex validation)
    (is_dm_participant(channel_id, auth.uid()))
    OR
    -- Public channels
    (EXISTS (
      SELECT 1 FROM channels
      WHERE channels.id::text = messages.channel_id 
      AND channels.is_private = false
    ))
    OR
    -- Channel creator
    (EXISTS (
      SELECT 1 FROM channels
      WHERE channels.id::text = messages.channel_id 
      AND channels.created_by = auth.uid()
    ))
    OR
    -- Private channel member
    (EXISTS (
      SELECT 1 FROM channels c
      JOIN channel_members cm ON c.id = cm.channel_id
      WHERE c.id::text = messages.channel_id 
      AND c.is_private = true 
      AND cm.user_id = auth.uid()
    ))
  )
);

-- Also update notifications policy to use secure DM validation
DROP POLICY IF EXISTS "Users can create notifications for valid interactions" ON public.notifications;

CREATE POLICY "Users can create notifications for valid interactions"
ON public.notifications
FOR INSERT
WITH CHECK (
  from_user_id = auth.uid() 
  AND (
    -- DM notifications: sender must be a participant
    is_dm_participant(channel_id, auth.uid())
    OR
    -- Channel notifications: both users must be members of the same channel
    EXISTS (
      SELECT 1 FROM channel_members cm1
      JOIN channel_members cm2 ON cm1.channel_id = cm2.channel_id
      WHERE cm1.user_id = auth.uid() 
      AND cm2.user_id = notifications.user_id
    )
  )
);