-- Fix security issues across multiple tables

-- 1. Fix profiles: Only allow viewing profiles of users you can interact with (same channels or online)
DROP POLICY IF EXISTS "Users can view all profiles" ON public.profiles;
CREATE POLICY "Users can view profiles" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (
  -- User can always see their own profile
  user_id = auth.uid()
  OR
  -- User can see profiles of users in same channels
  EXISTS (
    SELECT 1 FROM channel_members cm1
    JOIN channel_members cm2 ON cm1.channel_id = cm2.channel_id
    WHERE cm1.user_id = auth.uid() AND cm2.user_id = profiles.user_id
  )
  OR
  -- User can see profiles of online users (for DM list)
  is_online = true
);

-- 2. Fix voice_channel_participants: Only show participants to channel members
DROP POLICY IF EXISTS "Anyone can view voice participants" ON public.voice_channel_participants;
CREATE POLICY "Users can view voice participants in accessible channels" 
ON public.voice_channel_participants 
FOR SELECT 
TO authenticated
USING (
  -- Public voice channels
  EXISTS (
    SELECT 1 FROM channels 
    WHERE channels.id::text = voice_channel_participants.channel_id 
    AND channels.is_private = false
  )
  OR
  -- Private channels user is a member of
  EXISTS (
    SELECT 1 FROM channels c
    JOIN channel_members cm ON c.id = cm.channel_id
    WHERE c.id::text = voice_channel_participants.channel_id 
    AND c.is_private = true 
    AND cm.user_id = auth.uid()
  )
  OR
  -- Channel creator
  EXISTS (
    SELECT 1 FROM channels 
    WHERE channels.id::text = voice_channel_participants.channel_id 
    AND channels.created_by = auth.uid()
  )
);

-- 3. Fix channel_members: Only show memberships for accessible channels
DROP POLICY IF EXISTS "Members can view channel membership" ON public.channel_members;
CREATE POLICY "Users can view membership for accessible channels" 
ON public.channel_members 
FOR SELECT 
TO authenticated
USING (
  -- User can see their own memberships
  user_id = auth.uid()
  OR
  -- User can see memberships in public channels
  EXISTS (
    SELECT 1 FROM channels 
    WHERE channels.id = channel_members.channel_id 
    AND channels.is_private = false
  )
  OR
  -- User can see memberships in private channels they belong to
  EXISTS (
    SELECT 1 FROM channel_members cm2
    WHERE cm2.channel_id = channel_members.channel_id 
    AND cm2.user_id = auth.uid()
  )
  OR
  -- Channel creator can see all memberships
  EXISTS (
    SELECT 1 FROM channels 
    WHERE channels.id = channel_members.channel_id 
    AND channels.created_by = auth.uid()
  )
);

-- 4. Fix notifications: Only allow creating notifications for valid interactions
DROP POLICY IF EXISTS "Authenticated users can create notifications" ON public.notifications;
CREATE POLICY "Users can create notifications for valid interactions" 
ON public.notifications 
FOR INSERT 
TO authenticated
WITH CHECK (
  -- The from_user_id must be the current user
  from_user_id = auth.uid()
  AND
  -- The target user must be in a shared channel or the notification is for a DM
  (
    channel_id LIKE 'dm-%' 
    OR
    EXISTS (
      SELECT 1 FROM channel_members cm1
      JOIN channel_members cm2 ON cm1.channel_id = cm2.channel_id
      WHERE cm1.user_id = auth.uid() AND cm2.user_id = notifications.user_id
    )
  )
);

-- 5. Fix message_reactions: Only show reactions for accessible messages
DROP POLICY IF EXISTS "Anyone can view reactions" ON public.message_reactions;
CREATE POLICY "Users can view reactions for accessible messages" 
ON public.message_reactions 
FOR SELECT 
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM messages m
    WHERE m.id = message_reactions.message_id
    AND (
      -- DM messages user is part of
      (m.channel_id LIKE 'dm-%' AND m.channel_id LIKE '%' || auth.uid()::text || '%')
      OR
      -- Public channel messages
      EXISTS (
        SELECT 1 FROM channels 
        WHERE channels.id::text = m.channel_id 
        AND channels.is_private = false
      )
      OR
      -- Private channel messages user is a member of
      EXISTS (
        SELECT 1 FROM channels c
        JOIN channel_members cm ON c.id = cm.channel_id
        WHERE c.id::text = m.channel_id 
        AND c.is_private = true 
        AND cm.user_id = auth.uid()
      )
    )
  )
);