-- Fix channels SELECT policy
DROP POLICY IF EXISTS "Anyone can view public channels" ON public.channels;
CREATE POLICY "Anyone can view public channels" 
ON public.channels 
FOR SELECT 
TO authenticated
USING (
  is_private = false
  OR created_by = auth.uid()
  OR EXISTS (
    SELECT 1 FROM channel_members 
    WHERE channel_members.channel_id = channels.id 
    AND channel_members.user_id = auth.uid()
  )
);

-- Add UPDATE policy for messages (users can only update their own)
CREATE POLICY "Users can update own messages" 
ON public.messages 
FOR UPDATE 
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Add UPDATE policy for channel_members (immutable)
CREATE POLICY "Channel membership is immutable" 
ON public.channel_members 
FOR UPDATE 
TO authenticated
USING (false)
WITH CHECK (false);

-- Add UPDATE policy for message_reactions (immutable)
CREATE POLICY "Reactions are immutable" 
ON public.message_reactions 
FOR UPDATE 
TO authenticated
USING (false)
WITH CHECK (false);

-- Add DELETE policy for profiles
CREATE POLICY "Users can delete own profile or admins can delete" 
ON public.profiles 
FOR DELETE 
TO authenticated
USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'));

-- Create storage bucket for uploads
INSERT INTO storage.buckets (id, name, public) VALUES ('uploads', 'uploads', true) ON CONFLICT DO NOTHING;

-- Storage policies for uploads bucket
CREATE POLICY "Authenticated users can upload files"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'uploads');

CREATE POLICY "Anyone can view uploaded files"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'uploads');

CREATE POLICY "Users can delete own uploads"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'uploads' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Add banned_at column to profiles for banning users
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS banned_at timestamp with time zone DEFAULT NULL;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS banned_by uuid DEFAULT NULL;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS ban_reason text DEFAULT NULL;