-- Fix the security issue: Messages should only be viewable by authorized users
-- Drop the existing overly permissive policy
DROP POLICY IF EXISTS "Users can view messages in accessible channels" ON public.messages;

-- Create a proper policy that restricts message access
-- Users can only view messages in:
-- 1. DM channels they are part of (channel_id contains their user_id)
-- 2. Public channels they have access to
-- 3. Private channels they are members of
CREATE POLICY "Users can view messages in accessible channels" 
ON public.messages 
FOR SELECT 
TO authenticated
USING (
  -- DM channels: user must be part of the DM
  (channel_id LIKE 'dm-%' AND channel_id LIKE '%' || auth.uid()::text || '%')
  OR
  -- Public channels
  (EXISTS (
    SELECT 1 FROM channels 
    WHERE channels.id::text = messages.channel_id 
    AND channels.is_private = false
  ))
  OR
  -- Private channels user is a member of
  (EXISTS (
    SELECT 1 FROM channels c
    JOIN channel_members cm ON c.id = cm.channel_id
    WHERE c.id::text = messages.channel_id 
    AND c.is_private = true 
    AND cm.user_id = auth.uid()
  ))
  OR
  -- Channel creator can always see messages
  (EXISTS (
    SELECT 1 FROM channels 
    WHERE channels.id::text = messages.channel_id 
    AND channels.created_by = auth.uid()
  ))
);