-- Fix private channel access control gaps

-- Drop existing messages INSERT policy
DROP POLICY IF EXISTS "Authenticated users can send messages" ON messages;

-- Create new policy that validates channel access for messages
CREATE POLICY "Users can only message accessible channels"
ON messages FOR INSERT
WITH CHECK (
  auth.uid() = user_id AND
  (
    -- DM channels (channel_id starts with 'dm-')
    channel_id LIKE 'dm-%'
    OR
    -- Public channels
    EXISTS (SELECT 1 FROM channels WHERE id::text = messages.channel_id AND is_private = false)
    OR
    -- Creator can always message their own channels
    EXISTS (SELECT 1 FROM channels WHERE id::text = messages.channel_id AND created_by = auth.uid())
    OR
    -- Private channels where user is a member
    EXISTS (
      SELECT 1 FROM channels c
      JOIN channel_members cm ON c.id = cm.channel_id
      WHERE c.id::text = messages.channel_id 
      AND c.is_private = true
      AND cm.user_id = auth.uid()
    )
  )
);

-- Drop existing channel_members INSERT policy
DROP POLICY IF EXISTS "Users can join channels" ON channel_members;

-- Create new policy that restricts joining to public channels only (private requires join code via function)
CREATE POLICY "Users can only join public channels directly"
ON channel_members FOR INSERT
WITH CHECK (
  auth.uid() = user_id AND
  (
    -- Public channels - anyone can join
    EXISTS (SELECT 1 FROM channels WHERE id = channel_id AND is_private = false)
    OR
    -- Creator can add themselves to their own private channels
    EXISTS (SELECT 1 FROM channels WHERE id = channel_id AND created_by = auth.uid())
  )
);

-- Create a security definer function for joining private channels with join code
CREATE OR REPLACE FUNCTION public.join_private_channel(
  p_channel_id UUID,
  p_join_code TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_is_valid BOOLEAN;
BEGIN
  -- Check if channel exists, is private, and join code matches
  SELECT EXISTS (
    SELECT 1 FROM channels
    WHERE id = p_channel_id
      AND is_private = true
      AND join_code = p_join_code
  ) INTO v_is_valid;
  
  IF NOT v_is_valid THEN
    RETURN FALSE;
  END IF;
  
  -- Check if already a member
  IF EXISTS (
    SELECT 1 FROM channel_members
    WHERE channel_id = p_channel_id AND user_id = auth.uid()
  ) THEN
    RETURN TRUE; -- Already a member
  END IF;
  
  -- Insert the membership
  INSERT INTO channel_members (channel_id, user_id)
  VALUES (p_channel_id, auth.uid());
  
  RETURN TRUE;
END;
$$;