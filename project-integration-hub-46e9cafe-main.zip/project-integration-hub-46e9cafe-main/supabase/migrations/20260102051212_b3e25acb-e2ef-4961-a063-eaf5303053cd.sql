-- Drop the problematic policies
DROP POLICY IF EXISTS "Anyone can view public channels" ON public.channels;
DROP POLICY IF EXISTS "Users can view membership for accessible channels" ON public.channel_members;

-- Create a security definer function to check channel membership without RLS
CREATE OR REPLACE FUNCTION public.is_channel_member(_channel_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.channel_members
    WHERE channel_id = _channel_id AND user_id = _user_id
  )
$$;

-- Create a security definer function to check if channel is public
CREATE OR REPLACE FUNCTION public.is_channel_public(_channel_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.channels
    WHERE id = _channel_id AND is_private = false
  )
$$;

-- Create a security definer function to check if user created the channel
CREATE OR REPLACE FUNCTION public.is_channel_creator(_channel_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.channels
    WHERE id = _channel_id AND created_by = _user_id
  )
$$;

-- Recreate channels SELECT policy using security definer function
CREATE POLICY "Anyone can view public channels"
ON public.channels
FOR SELECT
USING (
  is_private = false 
  OR created_by = auth.uid() 
  OR public.is_channel_member(id, auth.uid())
);

-- Recreate channel_members SELECT policy using security definer functions
CREATE POLICY "Users can view membership for accessible channels"
ON public.channel_members
FOR SELECT
USING (
  user_id = auth.uid() 
  OR public.is_channel_public(channel_id)
  OR public.is_channel_creator(channel_id, auth.uid())
  OR public.is_channel_member(channel_id, auth.uid())
);