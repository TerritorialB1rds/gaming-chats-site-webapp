import { useEffect, useState, useCallback } from 'react';

interface SecurityCheckResult {
  isSecure: boolean;
  violations: string[];
  checking: boolean;
}

// Security check hook to detect potential tampering/userscripts
export function useSecurityCheck(): SecurityCheckResult {
  const [isSecure, setIsSecure] = useState(true);
  const [violations, setViolations] = useState<string[]>([]);
  const [checking, setChecking] = useState(true);

  const runSecurityChecks = useCallback(() => {
    const detectedViolations: string[] = [];

    try {
      // Check 1: Detect common userscript managers
      const userscriptManagers = [
        'GM_info', 'GM_getValue', 'GM_setValue', 'GM_xmlhttpRequest',
        'GM_addStyle', 'GM_registerMenuCommand', 'unsafeWindow'
      ];

      for (const manager of userscriptManagers) {
        if ((window as any)[manager] !== undefined) {
          detectedViolations.push('userscript_manager');
          break;
        }
      }

      // Check 2: Detect if Function constructor has been modified
      try {
        const testFunc = new Function('return 1');
        if (typeof testFunc !== 'function' || testFunc() !== 1) {
          detectedViolations.push('function_tampering');
        }
      } catch {
        detectedViolations.push('function_blocked');
      }

      // Check 3: Check for common browser extension injection patterns
      const suspiciousElements = document.querySelectorAll(
        '[data-extension], [data-injected], [class*="extension"], [class*="inject"], [class*="tampermonkey"], [class*="greasemonkey"], [class*="violentmonkey"]'
      );
      if (suspiciousElements.length > 0) {
        detectedViolations.push('extension_injection');
      }

      // Check 4: Verify window.fetch hasn't been tampered
      if (!window.fetch || window.fetch.toString().indexOf('[native code]') === -1) {
        detectedViolations.push('fetch_tampering');
      }

      // Check 5: Verify XMLHttpRequest hasn't been modified
      if (!window.XMLHttpRequest ||
          XMLHttpRequest.prototype.open.toString().indexOf('[native code]') === -1) {
        detectedViolations.push('xhr_tampering');
      }

      // Check 6: Detect if localStorage has been proxied
      try {
        const testKey = `__sec_check_${Date.now()}`;
        localStorage.setItem(testKey, 'test');
        const retrieved = localStorage.getItem(testKey);
        localStorage.removeItem(testKey);
        if (retrieved !== 'test') {
          detectedViolations.push('storage_tampering');
        }
      } catch {
        detectedViolations.push('storage_blocked');
      }

      // Check 7: Detect if console has been modified (common in debug bypasses)
      if (console.log.toString().indexOf('[native code]') === -1) {
        detectedViolations.push('console_tampering');
      }

      // Check 8: Check for Proxy wrapping on common globals
      const globalsToCheck = ['document', 'window', 'navigator'];
      for (const global of globalsToCheck) {
        try {
          const obj = (window as any)[global];
          // Proxies often throw when accessing certain properties
          if (obj && obj[Symbol.toStringTag] === 'Proxy') {
            detectedViolations.push(`${global}_proxy`);
          }
        } catch {
          detectedViolations.push(`${global}_access_blocked`);
        }
      }

      // Check 9: Verify MutationObserver is native (common target for DOM manipulation scripts)
      if (!window.MutationObserver ||
          MutationObserver.toString().indexOf('[native code]') === -1) {
        detectedViolations.push('mutation_observer_tampering');
      }

      // Check 10: Check for common automation/testing tools (skip in development/preview environments)
      const isDevEnvironment =
        window.location.hostname.includes('lovable.app') ||
        window.location.hostname.includes('lovableproject.com') ||
        window.location.hostname === 'localhost' ||
        window.location.hostname === '127.0.0.1';

      if (!isDevEnvironment) {
        const automationIndicators = [
          (window as any).__selenium_unwrapped,
          (window as any).__webdriver_evaluate,
          (window as any).__driver_evaluate,
          (window as any).__webdriver_unwrapped,
          (window as any).__fxdriver_evaluate,
          (window as any).callPhantom,
          (window as any)._phantom,
          (navigator as any).webdriver,
        ];

        if (automationIndicators.some(indicator => indicator !== undefined && indicator !== false)) {
          detectedViolations.push('automation_detected');
        }
      }

      // Check 11: Timing-based check for debugger statements
      const startTime = performance.now();
      // This is intentionally empty - debugger pauses would show timing differences
      const endTime = performance.now();
      if (endTime - startTime > 100) {
        detectedViolations.push('debugger_detected');
      }

    } catch (error) {
      // If any check throws, it might indicate tampering
      detectedViolations.push('check_failure');
    }

    setViolations(detectedViolations);
    setIsSecure(detectedViolations.length === 0);
    setChecking(false);
  }, []);

  useEffect(() => {
    // Run checks on mount
    runSecurityChecks();

    // Run checks periodically to detect runtime injections
    const interval = setInterval(runSecurityChecks, 30000);

    // Also run on visibility change (tab focus)
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        runSecurityChecks();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [runSecurityChecks]);

  return { isSecure, violations, checking };
}

// Helper to generate a security token for server validation
export function generateSecurityFingerprint(): string {
  const data = {
    timestamp: Date.now(),
    userAgent: navigator.userAgent,
    language: navigator.language,
    platform: navigator.platform,
    screenRes: `${window.screen.width}x${window.screen.height}`,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    cookieEnabled: navigator.cookieEnabled,
  };

  // Simple hash of the fingerprint data
  const str = JSON.stringify(data);
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }

  return `${hash.toString(36)}_${data.timestamp.toString(36)}`;
}
