import { useEffect, useState } from 'react'
import { supabase } from '@/integrations/supabase/client'

export type UserRole = 'admin' | 'moderator' | 'user' | null

export function useUserRole(userId: string | undefined) {
  const [role, setRole] = useState<UserRole>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!userId) {
      setRole(null)
      setLoading(false)
      return
    }

    const fetchRole = async () => {
      try {
        // Check if user has admin role
        const { data: hasAdmin } = await supabase
          .rpc('has_role', { _user_id: userId, _role: 'admin' })

        if (hasAdmin) {
          setRole('admin')
          return
        }

        // Check if user has moderator role
        const { data: hasModerator } = await supabase
          .rpc('has_role', { _user_id: userId, _role: 'moderator' })

        if (hasModerator) {
          setRole('moderator')
          return
        }

        // Default to user role
        setRole('user')
      } catch (error) {
        console.error('Error fetching user role:', error)
        setRole('user')
      } finally {
        setLoading(false)
      }
    }

    fetchRole()
  }, [userId])

  return { role, loading, isAdmin: role === 'admin', isModerator: role === 'moderator' }
}
