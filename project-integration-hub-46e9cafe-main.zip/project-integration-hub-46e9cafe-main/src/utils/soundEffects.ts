// Sound effects using Web Audio API
class SoundEffects {
  private audioContext: AudioContext | null = null
  private enabled: boolean = true

  constructor() {
    if (typeof window !== 'undefined' && 'AudioContext' in window) {
      this.audioContext = new AudioContext()
    }
  }

  setEnabled(enabled: boolean) {
    this.enabled = enabled
  }

  private playSound(
    frequency: number,
    duration: number,
    type: OscillatorType = 'sine',
    volume: number = 0.3
  ) {
    if (!this.enabled || !this.audioContext) return

    const oscillator = this.audioContext.createOscillator()
    const gainNode = this.audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(this.audioContext.destination)

    oscillator.frequency.value = frequency
    oscillator.type = type
    gainNode.gain.setValueAtTime(volume, this.audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(
      0.01,
      this.audioContext.currentTime + duration
    )

    oscillator.start(this.audioContext.currentTime)
    oscillator.stop(this.audioContext.currentTime + duration)
  }

  // Message notification - soft ping
  playMessageSound() {
    if (!this.audioContext) return

    const now = this.audioContext.currentTime
    const oscillator = this.audioContext.createOscillator()
    const gainNode = this.audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(this.audioContext.destination)

    oscillator.frequency.setValueAtTime(800, now)
    oscillator.type = 'sine'

    gainNode.gain.setValueAtTime(0.2, now)
    gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.3)

    oscillator.start(now)
    oscillator.stop(now + 0.3)
  }

  // Mention notification - attention-grabbing beep
  playMentionSound() {
    if (!this.audioContext) return

    const now = this.audioContext.currentTime

    // Play two tones for attention
    for (let i = 0; i < 2; i++) {
      const oscillator = this.audioContext.createOscillator()
      const gainNode = this.audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(this.audioContext.destination)

      const startTime = now + i * 0.15
      oscillator.frequency.setValueAtTime(1000, startTime)
      oscillator.type = 'sine'

      gainNode.gain.setValueAtTime(0.25, startTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + 0.1)

      oscillator.start(startTime)
      oscillator.stop(startTime + 0.1)
    }
  }

  // Call request - ringing sound
  playCallSound() {
    if (!this.audioContext) return

    const now = this.audioContext.currentTime

    // Create a repeating ring pattern
    for (let i = 0; i < 3; i++) {
      const oscillator = this.audioContext.createOscillator()
      const gainNode = this.audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(this.audioContext.destination)

      const startTime = now + i * 0.4
      oscillator.frequency.setValueAtTime(1200, startTime)
      oscillator.type = 'square'

      gainNode.gain.setValueAtTime(0.15, startTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + 0.2)

      oscillator.start(startTime)
      oscillator.stop(startTime + 0.2)
    }
  }

  // Success sound
  playSuccessSound() {
    if (!this.audioContext) return

    const now = this.audioContext.currentTime
    const frequencies = [523.25, 659.25, 783.99] // C, E, G chord

    frequencies.forEach((freq) => {
      const oscillator = this.audioContext!.createOscillator()
      const gainNode = this.audioContext!.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(this.audioContext!.destination)

      oscillator.frequency.setValueAtTime(freq, now)
      oscillator.type = 'sine'

      gainNode.gain.setValueAtTime(0.1, now)
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.4)

      oscillator.start(now)
      oscillator.stop(now + 0.4)
    })
  }
}

export const soundEffects = new SoundEffects()
