import { useState, useRef, useEffect } from 'react'
import { X, Minus, GripVertical, Users, MessageSquare, Shield, Trash2, Ban, Crown, UserX, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { supabase } from '@/integrations/supabase/client'
import { useToast } from '@/hooks/use-toast'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'

interface FloatingAdminPanelProps {
  isOpen: boolean
  onClose: () => void
  currentUserId?: string
}

interface UserData {
  user_id: string
  username: string
  is_online: boolean
  banned_at: string | null
  is_admin?: boolean
}

interface ChannelData {
  id: string
  name: string
  type: string
  is_private: boolean
  member_count?: number
}

export function FloatingAdminPanel({ isOpen, onClose, currentUserId }: FloatingAdminPanelProps) {
  const [position, setPosition] = useState({ x: 100, y: 100 })
  const [size, setSize] = useState({ width: 450, height: 550 })
  const [isDragging, setIsDragging] = useState(false)
  const [isResizing, setIsResizing] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [activeTab, setActiveTab] = useState<'users' | 'channels' | 'stats'>('stats')
  const [users, setUsers] = useState<UserData[]>([])
  const [channels, setChannels] = useState<ChannelData[]>([])
  const [loading, setLoading] = useState(false)
  const [confirmAction, setConfirmAction] = useState<{
    type: 'ban' | 'kick' | 'promote' | 'demote' | 'delete'
    target: { id: string; name: string }
  } | null>(null)
  const [banReason, setBanReason] = useState('')
  const dragOffset = useRef({ x: 0, y: 0 })
  const resizeStart = useRef({ x: 0, y: 0, width: 0, height: 0 })
  const { toast } = useToast()

  useEffect(() => {
    if (isOpen) {
      loadData()
    }
  }, [isOpen])

  const loadData = async () => {
    setLoading(true)

    // Get users with their roles
    const { data: profiles } = await supabase
      .from('profiles')
      .select('user_id, username, is_online, banned_at')
      .order('username')

    const { data: roles } = await supabase
      .from('user_roles')
      .select('user_id, role')
      .eq('role', 'admin')

    const adminUserIds = new Set(roles?.map(r => r.user_id) || [])

    if (profiles) {
      setUsers(profiles.map(p => ({
        ...p,
        is_admin: adminUserIds.has(p.user_id)
      })))
    }

    // Get channels with member counts
    const { data: channelsData } = await supabase
      .from('channels')
      .select('id, name, type, is_private')
      .order('name')

    if (channelsData) {
      const channelsWithCounts = await Promise.all(
        channelsData.map(async (channel) => {
          const { count } = await supabase
            .from('channel_members')
            .select('*', { count: 'exact', head: true })
            .eq('channel_id', channel.id)

          return { ...channel, member_count: count || 0 }
        })
      )
      setChannels(channelsWithCounts as ChannelData[])
    }

    setLoading(false)
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.no-drag')) return
    setIsDragging(true)
    dragOffset.current = {
      x: e.clientX - position.x,
      y: e.clientY - position.y
    }
  }

  const handleResizeMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsResizing(true)
    resizeStart.current = {
      x: e.clientX,
      y: e.clientY,
      width: size.width,
      height: size.height
    }
  }

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        setPosition({
          x: Math.max(0, Math.min(window.innerWidth - size.width, e.clientX - dragOffset.current.x)),
          y: Math.max(0, Math.min(window.innerHeight - 50, e.clientY - dragOffset.current.y))
        })
      }
      if (isResizing) {
        const deltaX = e.clientX - resizeStart.current.x
        const deltaY = e.clientY - resizeStart.current.y
        setSize({
          width: Math.max(350, resizeStart.current.width + deltaX),
          height: Math.max(300, resizeStart.current.height + deltaY)
        })
      }
    }

    const handleMouseUp = () => {
      setIsDragging(false)
      setIsResizing(false)
    }

    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove)
      window.addEventListener('mouseup', handleMouseUp)
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isDragging, isResizing, size.width])

  const banUser = async (userId: string) => {
    await supabase
      .from('profiles')
      .update({
        banned_at: new Date().toISOString(),
        banned_by: currentUserId,
        ban_reason: banReason || 'Banned by admin',
        is_online: false
      })
      .eq('user_id', userId)

    toast({ title: 'User banned' })
    loadData()
    setConfirmAction(null)
    setBanReason('')
  }

  const unbanUser = async (userId: string) => {
    await supabase
      .from('profiles')
      .update({ banned_at: null, banned_by: null, ban_reason: null })
      .eq('user_id', userId)

    toast({ title: 'User unbanned' })
    loadData()
  }

  const kickUser = async (userId: string) => {
    await supabase
      .from('profiles')
      .update({ is_online: false })
      .eq('user_id', userId)

    toast({ title: 'User kicked' })
    loadData()
    setConfirmAction(null)
  }

  const promoteToAdmin = async (userId: string) => {
    await supabase
      .from('user_roles')
      .insert({ user_id: userId, role: 'admin' })

    toast({ title: 'User promoted to admin' })
    loadData()
    setConfirmAction(null)
  }

  const demoteFromAdmin = async (userId: string) => {
    await supabase
      .from('user_roles')
      .delete()
      .eq('user_id', userId)
      .eq('role', 'admin')

    toast({ title: 'User demoted from admin' })
    loadData()
    setConfirmAction(null)
  }

  const deleteChannel = async (channelId: string) => {
    const { error } = await supabase.from('channels').delete().eq('id', channelId)
    if (error) {
      toast({ title: 'Error', description: 'Failed to delete channel', variant: 'destructive' })
    } else {
      toast({ title: 'Channel deleted' })
      loadData()
    }
    setConfirmAction(null)
  }

  const totalUsers = users.length
  const onlineUsers = users.filter(u => u.is_online).length
  const bannedUsers = users.filter(u => u.banned_at).length
  const adminCount = users.filter(u => u.is_admin).length

  if (!isOpen) return null

  return (
    <>
      <div
        className="fixed z-50 bg-card border border-border rounded-lg shadow-xl overflow-hidden"
        style={{
          left: position.x,
          top: position.y,
          width: size.width,
          height: isMinimized ? 40 : size.height
        }}
      >
        {/* Header */}
        <div
          className="h-10 bg-sidebar-background flex items-center justify-between px-3 cursor-move select-none"
          onMouseDown={handleMouseDown}
        >
          <div className="flex items-center gap-2">
            <GripVertical className="h-4 w-4 text-muted-foreground" />
            <Shield className="h-4 w-4 text-primary" />
            <span className="text-sm font-semibold">Admin Panel</span>
          </div>
          <div className="flex items-center gap-1 no-drag">
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={loadData}
              disabled={loading}
            >
              <RefreshCw className={`h-3 w-3 ${loading ? 'animate-spin' : ''}`} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={() => setIsMinimized(!isMinimized)}
            >
              <Minus className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 hover:bg-destructive/20 hover:text-destructive"
              onClick={onClose}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Tabs */}
            <div className="flex border-b border-border">
              <button
                onClick={() => setActiveTab('stats')}
                className={`flex-1 py-2 text-sm font-medium transition-colors no-drag ${
                  activeTab === 'stats' ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                📊 Stats
              </button>
              <button
                onClick={() => setActiveTab('users')}
                className={`flex-1 py-2 text-sm font-medium transition-colors no-drag ${
                  activeTab === 'users' ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Users className="h-4 w-4 inline mr-1" /> Users
              </button>
              <button
                onClick={() => setActiveTab('channels')}
                className={`flex-1 py-2 text-sm font-medium transition-colors no-drag ${
                  activeTab === 'channels' ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <MessageSquare className="h-4 w-4 inline mr-1" /> Channels
              </button>
            </div>

            {/* Content */}
            <ScrollArea className="no-drag" style={{ height: size.height - 90 }}>
              <div className="p-3 space-y-2">
                {activeTab === 'stats' && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-secondary/30 rounded-lg p-4 text-center">
                      <div className="text-3xl font-bold text-foreground">{totalUsers}</div>
                      <div className="text-sm text-muted-foreground">Total Users</div>
                    </div>
                    <div className="bg-green-500/10 rounded-lg p-4 text-center">
                      <div className="text-3xl font-bold text-green-500">{onlineUsers}</div>
                      <div className="text-sm text-muted-foreground">Online Now</div>
                    </div>
                    <div className="bg-primary/10 rounded-lg p-4 text-center">
                      <div className="text-3xl font-bold text-primary">{adminCount}</div>
                      <div className="text-sm text-muted-foreground">Admins</div>
                    </div>
                    <div className="bg-destructive/10 rounded-lg p-4 text-center">
                      <div className="text-3xl font-bold text-destructive">{bannedUsers}</div>
                      <div className="text-sm text-muted-foreground">Banned</div>
                    </div>
                    <div className="col-span-2 bg-secondary/30 rounded-lg p-4 text-center">
                      <div className="text-3xl font-bold text-foreground">{channels.length}</div>
                      <div className="text-sm text-muted-foreground">Total Channels</div>
                    </div>
                  </div>
                )}

                {activeTab === 'users' && users.map((user) => (
                  <div key={user.user_id} className="flex items-center justify-between p-2 bg-secondary/30 rounded-md">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <div className={`w-2 h-2 rounded-full shrink-0 ${
                        user.banned_at ? 'bg-destructive' : user.is_online ? 'bg-green-500' : 'bg-muted-foreground'
                      }`} />
                      <span className="text-sm truncate">{user.username}</span>
                      {user.is_admin && (
                        <Crown className="h-3 w-3 text-yellow-500 shrink-0" />
                      )}
                      {user.banned_at && (
                        <span className="text-xs text-destructive shrink-0">(Banned)</span>
                      )}
                    </div>
                    <TooltipProvider>
                      <div className="flex items-center gap-1 no-drag shrink-0">
                        {user.user_id !== currentUserId && (
                          <>
                            {user.banned_at ? (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 px-2 text-xs"
                                onClick={() => unbanUser(user.user_id)}
                              >
                                Unban
                              </Button>
                            ) : (
                              <>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-6 w-6 p-0 hover:bg-yellow-500/20 hover:text-yellow-500"
                                      onClick={() => setConfirmAction({
                                        type: user.is_admin ? 'demote' : 'promote',
                                        target: { id: user.user_id, name: user.username }
                                      })}
                                    >
                                      <Crown className="h-3 w-3" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>{user.is_admin ? 'Demote from Admin' : 'Promote to Admin'}</TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-6 w-6 p-0 hover:bg-orange-500/20 hover:text-orange-500"
                                      onClick={() => setConfirmAction({
                                        type: 'kick',
                                        target: { id: user.user_id, name: user.username }
                                      })}
                                    >
                                      <UserX className="h-3 w-3" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Kick User</TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-6 w-6 p-0 hover:bg-destructive/20 hover:text-destructive"
                                      onClick={() => setConfirmAction({
                                        type: 'ban',
                                        target: { id: user.user_id, name: user.username }
                                      })}
                                    >
                                      <Ban className="h-3 w-3" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Ban User</TooltipContent>
                                </Tooltip>
                              </>
                            )}
                          </>
                        )}
                      </div>
                    </TooltipProvider>
                  </div>
                ))}

                {activeTab === 'channels' && channels.map((channel) => (
                  <div key={channel.id} className="flex items-center justify-between p-2 bg-secondary/30 rounded-md">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <span className="text-sm truncate">{channel.is_private ? '🔒' : '#'} {channel.name}</span>
                      <span className="text-xs text-muted-foreground shrink-0">
                        ({channel.type}) • {channel.member_count} members
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 hover:bg-destructive/20 hover:text-destructive no-drag shrink-0"
                      onClick={() => setConfirmAction({
                        type: 'delete',
                        target: { id: channel.id, name: channel.name }
                      })}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Resize handle */}
            <div
              className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize no-drag"
              onMouseDown={handleResizeMouseDown}
            >
              <div className="absolute bottom-1 right-1 w-2 h-2 border-r-2 border-b-2 border-muted-foreground opacity-50" />
            </div>
          </>
        )}
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={!!confirmAction} onOpenChange={() => setConfirmAction(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmAction?.type === 'ban' && `Ban ${confirmAction?.target.name}?`}
              {confirmAction?.type === 'kick' && `Kick ${confirmAction?.target.name}?`}
              {confirmAction?.type === 'promote' && `Promote ${confirmAction?.target.name} to Admin?`}
              {confirmAction?.type === 'demote' && `Demote ${confirmAction?.target.name} from Admin?`}
              {confirmAction?.type === 'delete' && `Delete channel #${confirmAction?.target.name}?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmAction?.type === 'ban' && 'This user will be banned and unable to access the chat.'}
              {confirmAction?.type === 'kick' && 'This user will be kicked from the chat and marked as offline.'}
              {confirmAction?.type === 'promote' && 'This user will have admin privileges.'}
              {confirmAction?.type === 'demote' && 'This user will lose admin privileges.'}
              {confirmAction?.type === 'delete' && 'This channel and all its messages will be permanently deleted.'}
            </AlertDialogDescription>
            {confirmAction?.type === 'ban' && (
              <Input
                placeholder="Ban reason (optional)"
                value={banReason}
                onChange={(e) => setBanReason(e.target.value)}
                className="mt-2"
              />
            )}
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (!confirmAction) return
                switch (confirmAction.type) {
                  case 'ban':
                    banUser(confirmAction.target.id)
                    break
                  case 'kick':
                    kickUser(confirmAction.target.id)
                    break
                  case 'promote':
                    promoteToAdmin(confirmAction.target.id)
                    break
                  case 'demote':
                    demoteFromAdmin(confirmAction.target.id)
                    break
                  case 'delete':
                    deleteChannel(confirmAction.target.id)
                    break
                }
              }}
              className={confirmAction?.type === 'ban' || confirmAction?.type === 'delete' ? 'bg-destructive hover:bg-destructive/90' : ''}
            >
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
