import { useState, useEffect } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Bell, Check, X } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { soundEffects } from '@/utils/soundEffects'

interface Notification {
  id: string
  type: string
  content: string
  channel_id: string
  from_user_id: string
  is_read: boolean
  created_at: string
  fromUsername?: string
}

interface NotificationCenterProps {
  currentUserId: string
  onNotificationClick: (channelId: string) => void
}

export function NotificationCenter({ currentUserId, onNotificationClick }: NotificationCenterProps) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    loadNotifications()
    
    const subscription = supabase
      .channel('notifications')
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'notifications',
        filter: `user_id=eq.${currentUserId}`
      }, async (payload) => {
        // Play notification sound
        if (payload.new.type === 'mention') {
          soundEffects.playMentionSound()
        } else {
          soundEffects.playMessageSound()
        }

        // Fetch username
        const { data: profile } = await supabase
          .from('profiles')
          .select('username')
          .eq('user_id', payload.new.from_user_id)
          .single()

        const newNotification = {
          ...payload.new,
          fromUsername: profile?.username || 'Someone'
        } as Notification

        setNotifications(prev => [newNotification, ...prev])
      })
      .subscribe()

    return () => { supabase.removeChannel(subscription) }
  }, [currentUserId])

  const loadNotifications = async () => {
    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', currentUserId)
      .order('created_at', { ascending: false })
      .limit(50)

    if (!data) return

    // Fetch usernames for notifications
    const userIds = Array.from(new Set(data.map(n => n.from_user_id)))
    const { data: profiles } = await supabase
      .from('profiles')
      .select('user_id, username')
      .in('user_id', userIds)

    const usernameMap = new Map(profiles?.map(p => [p.user_id, p.username]) || [])
    
    setNotifications(data.map(n => ({
      ...n,
      fromUsername: usernameMap.get(n.from_user_id) || 'Someone'
    })))
  }

  const markAsRead = async (id: string) => {
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', id)

    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, is_read: true } : n)
    )
  }

  const markAllAsRead = async () => {
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', currentUserId)
      .eq('is_read', false)

    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })))
  }

  const deleteNotification = async (id: string) => {
    await supabase
      .from('notifications')
      .delete()
      .eq('id', id)

    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  const unreadCount = notifications.filter(n => !n.is_read).length

  const handleNotificationClick = (notification: Notification) => {
    markAsRead(notification.id)
    onNotificationClick(notification.channel_id)
    setIsOpen(false)
  }

  const getNotificationText = (notification: Notification) => {
    switch (notification.type) {
      case 'mention':
        return `${notification.fromUsername} mentioned you`
      case 'dm':
        return `${notification.fromUsername} sent you a message`
      case 'reaction':
        return `${notification.fromUsername} reacted to your message`
      default:
        return notification.content || 'New notification'
    }
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="h-10 w-10 p-0 relative"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center font-medium">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between p-3 border-b border-border">
          <h3 className="font-semibold">Notifications</h3>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllAsRead}>
              <Check className="h-4 w-4 mr-1" />
              Mark all read
            </Button>
          )}
        </div>

        <ScrollArea className="max-h-[400px]">
          {notifications.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground text-sm">
              No notifications yet
            </div>
          ) : (
            <div className="divide-y divide-border">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-3 flex items-start gap-3 hover:bg-secondary/50 transition-colors cursor-pointer ${
                    !notification.is_read ? 'bg-primary/5' : ''
                  }`}
                  onClick={() => handleNotificationClick(notification)}
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm">{getNotificationText(notification)}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 shrink-0"
                    onClick={(e) => {
                      e.stopPropagation()
                      deleteNotification(notification.id)
                    }}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  )
}
