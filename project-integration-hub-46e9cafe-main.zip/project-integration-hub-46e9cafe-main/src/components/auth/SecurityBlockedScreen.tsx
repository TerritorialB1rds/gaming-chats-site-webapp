import { Shield, AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface SecurityBlockedScreenProps {
  violations: string[];
  onRetry: () => void;
}

export function SecurityBlockedScreen({ violations, onRetry }: SecurityBlockedScreenProps) {
  const getViolationMessage = (violation: string): string => {
    const messages: Record<string, string> = {
      userscript_manager: 'Userscript manager detected (Tampermonkey, Greasemonkey, etc.)',
      function_tampering: 'JavaScript Function constructor has been modified',
      function_blocked: 'JavaScript execution is restricted',
      extension_injection: 'Browser extension injecting content into the page',
      fetch_tampering: 'Network request handler has been modified',
      xhr_tampering: 'XMLHttpRequest has been modified',
      storage_tampering: 'Browser storage has been modified',
      storage_blocked: 'Browser storage access blocked',
      console_tampering: 'Developer console has been modified',
      mutation_observer_tampering: 'DOM observer has been modified',
      automation_detected: 'Browser automation tools detected',
      debugger_detected: 'Debugger breakpoints detected',
      check_failure: 'Security check could not complete',
    };

    return messages[violation] || `Unknown violation: ${violation}`;
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-subtle p-4">
      <Card className="w-full max-w-lg shadow-lg animate-fade-in rounded-2xl border-destructive/30 bg-card">
        <CardHeader className="text-center space-y-4 pb-6">
          <div className="mx-auto w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center">
            <Shield className="h-8 w-8 text-destructive" />
          </div>
          <CardTitle className="text-2xl font-bold text-destructive">
            Security Check Failed
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center text-muted-foreground">
            <p className="mb-4">
              We detected potential security issues that prevent you from accessing Gaming Chats.
              This is to protect all users from malicious activity.
            </p>
          </div>

          <div className="bg-destructive/5 rounded-lg p-4 border border-destructive/20">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              <span className="font-semibold text-foreground">Issues Detected:</span>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {violations.map((violation, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-destructive mt-0.5">•</span>
                  <span>{getViolationMessage(violation)}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-muted/30 rounded-lg p-4 text-sm text-muted-foreground">
            <p className="font-medium text-foreground mb-2">To resolve this issue:</p>
            <ol className="list-decimal list-inside space-y-1">
              <li>Disable any userscript managers (Tampermonkey, Greasemonkey, etc.)</li>
              <li>Disable browser extensions that modify web pages</li>
              <li>Close any developer tools or debuggers</li>
              <li>Use a standard browser without automation tools</li>
              <li>Refresh the page and try again</li>
            </ol>
          </div>

          <Button
            onClick={onRetry}
            className="w-full h-11 font-semibold"
            variant="outline"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry Security Check
          </Button>

          <p className="text-xs text-center text-muted-foreground">
            If you believe this is an error, please contact support.
            Your security is our priority.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
