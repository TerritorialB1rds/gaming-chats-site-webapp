import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { authSchema } from '@/lib/validations';
import { Gamepad2, Shield } from 'lucide-react';
import { getSafeErrorMessage, logError } from '@/lib/errorUtils';

export function AuthForm() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validate inputs
      const validation = authSchema.safeParse({ username, password });
      if (!validation.success) {
        const errors = validation.error.errors.map(err => err.message).join(', ');
        throw new Error(errors);
      }

      const uname = validation.data.username.toLowerCase();

      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({
          email: `${uname}@local.app`,
          password
        });
        if (error) throw error;
      } else {
        // Check if username is available before signing up
        const { data: isAvailable } = await supabase
          .rpc('is_username_available', { _username: uname })

        if (!isAvailable) {
          throw new Error('This username is already taken. Please choose another.')
        }

        const redirectUrl = `${window.location.origin}/`;
        const { error: signUpError } = await supabase.auth.signUp({
          email: `${uname}@local.app`,
          password,
          options: {
            emailRedirectTo: redirectUrl,
            data: { username }
          }
        });
        if (signUpError) throw signUpError;

        // Auto sign-in
        const { error: signInAfterSignUpError } = await supabase.auth.signInWithPassword({
          email: `${uname}@local.app`,
          password
        });
        if (signInAfterSignUpError && /email not confirmed/i.test(signInAfterSignUpError.message)) {
          throw new Error('Email confirmation is enabled. Disable "Confirm email" in Supabase Auth settings to use username+password without emails.');
        } else if (signInAfterSignUpError) {
          throw signInAfterSignUpError;
        }
      }

      toast({
        title: isLogin ? 'Welcome back!' : 'Account created!',
        description: `Successfully ${isLogin ? 'logged in' : 'signed up'}`
      });
    } catch (error: unknown) {
      logError(error, 'authentication')
      toast({
        title: 'Error',
        description: getSafeErrorMessage(error, 'auth'),
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-subtle p-4">
      {/* Decorative background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <Card className="w-full max-w-md shadow-2xl animate-fade-in rounded-2xl border-border/30 bg-card/95 backdrop-blur-sm relative z-10">
        <CardHeader className="text-center space-y-4 pb-6">
          {/* Logo/Icon */}
          <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-primary">
            <Gamepad2 className="h-8 w-8 text-primary-foreground" />
          </div>

          <div className="space-y-2">
            <CardTitle className="text-3xl font-display font-bold text-gradient-primary tracking-tight">
              Gaming Chats
            </CardTitle>
            <CardDescription className="text-base text-muted-foreground">
              {isLogin ? 'Welcome back to the community!' : 'Join the Gaming Chats community!'}
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <form onSubmit={handleAuth} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm font-semibold text-foreground">
                Username
              </Label>
              <Input
                id="username"
                type="text"
                placeholder="Enter your username"
                value={username}
                onChange={e => setUsername(e.target.value)}
                required
                className="h-12 rounded-xl border-border/50 bg-background/50 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all placeholder:text-muted-foreground/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-semibold text-foreground">
                Password
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                className="h-12 rounded-xl border-border/50 bg-background/50 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all placeholder:text-muted-foreground/50"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 bg-gradient-primary hover:opacity-90 transition-all font-semibold text-base rounded-xl shadow-primary text-primary-foreground"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <div className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                  Loading...
                </span>
              ) : (
                isLogin ? 'Sign In' : 'Create Account'
              )}
            </Button>
          </form>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border/50" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">or</span>
            </div>
          </div>

          <Button
            variant="ghost"
            onClick={() => setIsLogin(!isLogin)}
            className="w-full text-sm hover:text-primary hover:bg-primary/5 transition-colors rounded-xl h-10"
          >
            {isLogin ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
          </Button>

          {/* Security badge */}
          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground pt-2">
            <Shield className="h-3.5 w-3.5 text-green-500" />
            <span>Protected by security monitoring</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
