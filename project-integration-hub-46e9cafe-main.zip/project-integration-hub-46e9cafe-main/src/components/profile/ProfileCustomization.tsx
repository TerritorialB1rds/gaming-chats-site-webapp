import { useState, useRef } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Camera, Upload, Loader2 } from 'lucide-react'

interface Profile {
  id: string
  username: string
  avatar_url?: string
  bio?: string
  pronouns?: string
  banner_url?: string
  activity?: string
  activity_details?: string
}

interface ProfileCustomizationProps {
  isOpen: boolean
  onClose: () => void
  profile: Profile
  onUpdate: (profile: Profile) => void
}

export function ProfileCustomization({ isOpen, onClose, profile, onUpdate }: ProfileCustomizationProps) {
  const [username, setUsername] = useState(profile.username)
  const [bio, setBio] = useState(profile.bio || '')
  const [pronouns, setPronouns] = useState(profile.pronouns || '')
  const [avatarUrl, setAvatarUrl] = useState(profile.avatar_url || '')
  const [bannerUrl, setBannerUrl] = useState(profile.banner_url || '')
  const [activity, setActivity] = useState(profile.activity || '')
  const [activityDetails, setActivityDetails] = useState(profile.activity_details || '')
  const [saving, setSaving] = useState(false)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)
  const [uploadingBanner, setUploadingBanner] = useState(false)
  const [usernameError, setUsernameError] = useState('')
  const avatarInputRef = useRef<HTMLInputElement>(null)
  const bannerInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const checkUsernameAvailable = async (newUsername: string) => {
    if (!newUsername.trim() || newUsername.toLowerCase() === profile.username.toLowerCase()) {
      setUsernameError('')
      return true
    }

    const { data, error } = await supabase
      .rpc('is_username_available', { 
        _username: newUsername.trim(),
        _exclude_user_id: profile.id 
      })

    if (error) {
      console.error('Error checking username:', error)
      return true
    }

    if (!data) {
      setUsernameError('This username is already taken')
      return false
    }

    setUsernameError('')
    return true
  }

  const handleUsernameChange = (value: string) => {
    setUsername(value)
    setUsernameError('')
  }

  const handleUsernameBlur = () => {
    if (username.trim()) {
      checkUsernameAvailable(username)
    }
  }

  const uploadFile = async (file: File, type: 'avatar' | 'banner') => {
    const isAvatar = type === 'avatar'
    isAvatar ? setUploadingAvatar(true) : setUploadingBanner(true)

    try {
      const fileExt = file.name.split('.').pop()
      const fileName = `${profile.id}/${type}-${Date.now()}.${fileExt}`
      
      const { error: uploadError } = await supabase.storage
        .from('uploads')
        .upload(fileName, file, { upsert: true })

      if (uploadError) throw uploadError

      const { data: { publicUrl } } = supabase.storage
        .from('uploads')
        .getPublicUrl(fileName)

      if (isAvatar) {
        setAvatarUrl(publicUrl)
      } else {
        setBannerUrl(publicUrl)
      }

      toast({ title: 'Upload successful', description: `${type} updated!` })
    } catch (error) {
      console.error('Upload error:', error)
      toast({ title: 'Upload failed', description: 'Could not upload file', variant: 'destructive' })
    } finally {
      isAvatar ? setUploadingAvatar(false) : setUploadingBanner(false)
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'banner') => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({ title: 'Invalid file', description: 'Please select an image file', variant: 'destructive' })
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: 'File too large', description: 'Maximum file size is 5MB', variant: 'destructive' })
      return
    }

    uploadFile(file, type)
  }

  const handleSave = async () => {
    if (!username.trim()) {
      toast({ title: 'Error', description: 'Username is required', variant: 'destructive' })
      return
    }

    // Check username availability before saving
    const isAvailable = await checkUsernameAvailable(username)
    if (!isAvailable) {
      toast({ title: 'Error', description: 'Username is already taken', variant: 'destructive' })
      return
    }

    setSaving(true)
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          username: username.trim(),
          bio: bio.trim() || null,
          pronouns: pronouns.trim() || null,
          avatar_url: avatarUrl.trim() || null,
          banner_url: bannerUrl.trim() || null,
          activity: activity.trim() || null,
          activity_details: activityDetails.trim() || null,
        })
        .eq('user_id', profile.id)

      if (error) {
        if (error.code === '23505') {
          setUsernameError('This username is already taken')
          throw new Error('Username already taken')
        }
        throw error
      }

      onUpdate({
        ...profile,
        username: username.trim(),
        bio: bio.trim(),
        pronouns: pronouns.trim(),
        avatar_url: avatarUrl.trim(),
        banner_url: bannerUrl.trim(),
        activity: activity.trim(),
        activity_details: activityDetails.trim(),
      })

      toast({ title: 'Profile updated', description: 'Your profile has been saved' })
      onClose()
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to update profile', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-card border-border max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-foreground">Edit Profile</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Banner Upload */}
          <div 
            className="h-24 rounded-lg bg-gradient-to-r from-primary/20 to-primary/40 relative overflow-hidden cursor-pointer group"
            style={bannerUrl ? { backgroundImage: `url(${bannerUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}
            onClick={() => bannerInputRef.current?.click()}
          >
            <div className="absolute inset-0 flex items-center justify-center bg-background/40 opacity-0 group-hover:opacity-100 transition-opacity">
              {uploadingBanner ? (
                <Loader2 className="h-6 w-6 text-foreground animate-spin" />
              ) : (
                <div className="flex flex-col items-center gap-1">
                  <Camera className="h-6 w-6 text-foreground" />
                  <span className="text-xs text-foreground">Upload Banner</span>
                </div>
              )}
            </div>
            <input
              ref={bannerInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handleFileSelect(e, 'banner')}
            />
          </div>

          {/* Avatar Upload */}
          <div className="flex items-center gap-4 -mt-10 ml-4">
            <div 
              className="relative cursor-pointer group"
              onClick={() => avatarInputRef.current?.click()}
            >
              <Avatar className="h-16 w-16 border-4 border-card">
                {avatarUrl ? (
                  <AvatarImage src={avatarUrl} alt={username} />
                ) : (
                  <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                    {username.charAt(0).toUpperCase()}
                  </AvatarFallback>
                )}
              </Avatar>
              <div className="absolute inset-0 rounded-full flex items-center justify-center bg-background/60 opacity-0 group-hover:opacity-100 transition-opacity">
                {uploadingAvatar ? (
                  <Loader2 className="h-5 w-5 text-foreground animate-spin" />
                ) : (
                  <Upload className="h-5 w-5 text-foreground" />
                )}
              </div>
              <input
                ref={avatarInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleFileSelect(e, 'avatar')}
              />
            </div>
            <span className="text-xs text-muted-foreground">Click to upload</span>
          </div>

          <div className="space-y-3">
            <div>
              <Label htmlFor="username" className="text-foreground">Username</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => handleUsernameChange(e.target.value)}
                onBlur={handleUsernameBlur}
                className={`bg-input border-border ${usernameError ? 'border-destructive' : ''}`}
                maxLength={32}
              />
              {usernameError && (
                <p className="text-xs text-destructive mt-1">{usernameError}</p>
              )}
            </div>

            <div>
              <Label htmlFor="pronouns" className="text-foreground">Pronouns</Label>
              <Input
                id="pronouns"
                value={pronouns}
                onChange={(e) => setPronouns(e.target.value)}
                placeholder="e.g., they/them, he/him, she/her"
                className="bg-input border-border"
                maxLength={20}
              />
            </div>

            <div>
              <Label htmlFor="bio" className="text-foreground">About Me</Label>
              <Textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Tell others about yourself..."
                className="bg-input border-border resize-none"
                rows={3}
                maxLength={190}
              />
              <span className="text-xs text-muted-foreground">{bio.length}/190</span>
            </div>

            <div>
              <Label htmlFor="avatar" className="text-foreground">Avatar URL (or upload above)</Label>
              <Input
                id="avatar"
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                placeholder="https://example.com/avatar.png"
                className="bg-input border-border"
              />
            </div>

            <div>
              <Label htmlFor="banner" className="text-foreground">Banner URL (or upload above)</Label>
              <Input
                id="banner"
                value={bannerUrl}
                onChange={(e) => setBannerUrl(e.target.value)}
                placeholder="https://example.com/banner.png"
                className="bg-input border-border"
              />
            </div>

            <div>
              <Label htmlFor="activity" className="text-foreground">Status</Label>
              <Input
                id="activity"
                value={activity}
                onChange={(e) => setActivity(e.target.value)}
                placeholder="e.g., Playing, Listening to, Watching"
                className="bg-input border-border"
                maxLength={50}
              />
            </div>

            <div>
              <Label htmlFor="activityDetails" className="text-foreground">Status Details</Label>
              <Input
                id="activityDetails"
                value={activityDetails}
                onChange={(e) => setActivityDetails(e.target.value)}
                placeholder="e.g., Minecraft, Spotify, YouTube"
                className="bg-input border-border"
                maxLength={50}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" onClick={onClose} disabled={saving}>
              Cancel
            </Button>
            <Button 
              onClick={handleSave} 
              disabled={saving || !username.trim() || !!usernameError || uploadingAvatar || uploadingBanner}
            >
              {saving ? 'Saving...' : 'Save'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}