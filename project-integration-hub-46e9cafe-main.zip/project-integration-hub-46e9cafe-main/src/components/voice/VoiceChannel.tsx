import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Mic, MicOff, Volume2, VolumeX, PhoneOff, ScreenShare, ScreenShareOff, AlertTriangle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { soundEffects } from '@/utils/soundEffects'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'

interface VoiceChannelProps {
  channelId: string
  channelName: string
  currentUserId: string
  currentUsername: string
}

interface Participant {
  id: string
  user_id: string
  username: string
  is_muted: boolean
  is_screensharing: boolean
}

export function VoiceChannel({ channelId, channelName, currentUserId, currentUsername }: VoiceChannelProps) {
  const [isConnected, setIsConnected] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isDeafened, setIsDeafened] = useState(false)
  const [participants, setParticipants] = useState<Participant[]>([])
  const [isScreensharing, setIsScreensharing] = useState(false)
  const [showWarning, setShowWarning] = useState(false)
  const { toast } = useToast()
  
  const streamRef = useRef<MediaStream | null>(null)
  const screenStreamRef = useRef<MediaStream | null>(null)
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map())
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const audioElementsRef = useRef<Map<string, HTMLAudioElement>>(new Map())

  useEffect(() => {
    loadParticipants()

    const subscription = supabase
      .channel(`voice-participants:${channelId}`)
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'voice_channel_participants',
        filter: `channel_id=eq.${channelId}`
      }, () => {
        loadParticipants()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
      if (isConnected) {
        leaveChannel()
      }
    }
  }, [channelId])

  const loadParticipants = async () => {
    const { data: participantData } = await supabase
      .from('voice_channel_participants')
      .select('id, user_id, is_muted, is_screensharing')
      .eq('channel_id', channelId)

    if (!participantData || participantData.length === 0) {
      setParticipants([])
      return
    }

    const userIds = participantData.map(p => p.user_id)
    const { data: profiles } = await supabase
      .from('profiles')
      .select('user_id, username')
      .in('user_id', userIds)

    const usernameMap = new Map(profiles?.map(p => [p.user_id, p.username]) || [])

    setParticipants(participantData.map(p => ({
      ...p,
      username: usernameMap.get(p.user_id) || 'Unknown'
    })))
  }

  const joinChannel = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream

      // Add to database
      await supabase
        .from('voice_channel_participants')
        .insert({
          channel_id: channelId,
          user_id: currentUserId,
          is_muted: false,
          is_screensharing: false
        })

      // Set up WebRTC signaling
      channelRef.current = supabase.channel(`voice-webrtc:${channelId}`)
      
      channelRef.current
        .on('broadcast', { event: 'webrtc-offer' }, async ({ payload }) => {
          if (payload.targetUserId === currentUserId) {
            await handleOffer(payload.fromUserId, payload.offer)
          }
        })
        .on('broadcast', { event: 'webrtc-answer' }, async ({ payload }) => {
          if (payload.targetUserId === currentUserId) {
            const pc = peerConnectionsRef.current.get(payload.fromUserId)
            if (pc) {
              await pc.setRemoteDescription(payload.answer)
            }
          }
        })
        .on('broadcast', { event: 'webrtc-ice' }, async ({ payload }) => {
          if (payload.targetUserId === currentUserId) {
            const pc = peerConnectionsRef.current.get(payload.fromUserId)
            if (pc) {
              await pc.addIceCandidate(payload.candidate)
            }
          }
        })
        .on('broadcast', { event: 'user-joined' }, async ({ payload }) => {
          if (payload.userId !== currentUserId) {
            await initiateConnection(payload.userId)
          }
        })
        .subscribe(async (status) => {
          if (status === 'SUBSCRIBED') {
            // Notify others we joined
            channelRef.current?.send({
              type: 'broadcast',
              event: 'user-joined',
              payload: { userId: currentUserId }
            })
          }
        })

      setIsConnected(true)
      soundEffects.playSuccessSound()
      toast({ title: 'Joined voice channel', description: channelName })

      // Connect to existing participants
      const { data: existingParticipants } = await supabase
        .from('voice_channel_participants')
        .select('user_id')
        .eq('channel_id', channelId)
        .neq('user_id', currentUserId)

      for (const p of existingParticipants || []) {
        await initiateConnection(p.user_id)
      }
    } catch (error) {
      console.error('Error joining voice channel:', error)
      toast({
        title: 'Error',
        description: 'Could not join voice channel. Please check microphone permissions.',
        variant: 'destructive'
      })
    }
  }

  const initiateConnection = async (targetUserId: string) => {
    const pc = createPeerConnection(targetUserId)
    
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        pc.addTrack(track, streamRef.current!)
      })
    }

    const offer = await pc.createOffer()
    await pc.setLocalDescription(offer)

    channelRef.current?.send({
      type: 'broadcast',
      event: 'webrtc-offer',
      payload: { fromUserId: currentUserId, targetUserId, offer }
    })
  }

  const handleOffer = async (fromUserId: string, offer: RTCSessionDescriptionInit) => {
    const pc = createPeerConnection(fromUserId)
    
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        pc.addTrack(track, streamRef.current!)
      })
    }

    await pc.setRemoteDescription(offer)
    const answer = await pc.createAnswer()
    await pc.setLocalDescription(answer)

    channelRef.current?.send({
      type: 'broadcast',
      event: 'webrtc-answer',
      payload: { fromUserId: currentUserId, targetUserId: fromUserId, answer }
    })
  }

  const createPeerConnection = (userId: string): RTCPeerConnection => {
    const pc = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    })

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        channelRef.current?.send({
          type: 'broadcast',
          event: 'webrtc-ice',
          payload: { fromUserId: currentUserId, targetUserId: userId, candidate: event.candidate }
        })
      }
    }

    pc.ontrack = (event) => {
      let audio = audioElementsRef.current.get(userId)
      if (!audio) {
        audio = new Audio()
        audio.autoplay = true
        audioElementsRef.current.set(userId, audio)
      }
      audio.srcObject = event.streams[0]
      audio.muted = isDeafened
    }

    peerConnectionsRef.current.set(userId, pc)
    return pc
  }

  const leaveChannel = async () => {
    // Clean up streams
    streamRef.current?.getTracks().forEach(track => track.stop())
    screenStreamRef.current?.getTracks().forEach(track => track.stop())
    streamRef.current = null
    screenStreamRef.current = null

    // Clean up peer connections
    peerConnectionsRef.current.forEach(pc => pc.close())
    peerConnectionsRef.current.clear()

    // Clean up audio elements
    audioElementsRef.current.forEach(audio => {
      audio.srcObject = null
    })
    audioElementsRef.current.clear()

    // Clean up signaling channel
    if (channelRef.current) {
      channelRef.current.unsubscribe()
      channelRef.current = null
    }

    // Remove from database
    await supabase
      .from('voice_channel_participants')
      .delete()
      .eq('channel_id', channelId)
      .eq('user_id', currentUserId)

    setIsConnected(false)
    setIsMuted(false)
    setIsDeafened(false)
    setIsScreensharing(false)
    toast({ title: 'Left voice channel' })
  }

  const toggleMute = async () => {
    if (streamRef.current) {
      const audioTrack = streamRef.current.getAudioTracks()[0]
      if (audioTrack) {
        audioTrack.enabled = isMuted
        setIsMuted(!isMuted)

        await supabase
          .from('voice_channel_participants')
          .update({ is_muted: !isMuted })
          .eq('channel_id', channelId)
          .eq('user_id', currentUserId)
      }
    }
  }

  const toggleDeafen = () => {
    const newDeafened = !isDeafened
    setIsDeafened(newDeafened)

    audioElementsRef.current.forEach(audio => {
      audio.muted = newDeafened
    })

    // Also mute when deafened
    if (newDeafened && !isMuted) {
      toggleMute()
    }
  }

  const toggleScreenShare = async () => {
    if (isScreensharing) {
      screenStreamRef.current?.getTracks().forEach(track => track.stop())
      screenStreamRef.current = null
      setIsScreensharing(false)

      await supabase
        .from('voice_channel_participants')
        .update({ is_screensharing: false })
        .eq('channel_id', channelId)
        .eq('user_id', currentUserId)
    } else {
      try {
        const screen = await navigator.mediaDevices.getDisplayMedia({ video: true })
        screenStreamRef.current = screen
        setIsScreensharing(true)

        await supabase
          .from('voice_channel_participants')
          .update({ is_screensharing: true })
          .eq('channel_id', channelId)
          .eq('user_id', currentUserId)

        screen.getVideoTracks()[0].onended = () => {
          setIsScreensharing(false)
          supabase
            .from('voice_channel_participants')
            .update({ is_screensharing: false })
            .eq('channel_id', channelId)
            .eq('user_id', currentUserId)
        }
      } catch (error) {
        console.error('Screen share error:', error)
      }
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="h-12 px-4 flex items-center gap-2 border-b border-border shadow-sm bg-background">
        <Volume2 className="h-5 w-5 text-muted-foreground" />
        <span className="font-display font-semibold">{channelName}</span>
        <span className="text-sm text-muted-foreground ml-2">
          {participants.length} connected
        </span>
      </div>

      <div className="flex-1 p-4">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {participants.map((participant) => (
            <div
              key={participant.id}
              className="flex flex-col items-center p-4 bg-secondary/30 rounded-lg"
            >
              <div className="relative">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                    {participant.username.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                {participant.is_muted && (
                  <div className="absolute -bottom-1 -right-1 bg-destructive rounded-full p-1">
                    <MicOff className="h-3 w-3 text-destructive-foreground" />
                  </div>
                )}
                {participant.is_screensharing && (
                  <div className="absolute -top-1 -right-1 bg-green-500 rounded-full p-1">
                    <ScreenShare className="h-3 w-3 text-white" />
                  </div>
                )}
              </div>
              <span className="mt-2 text-sm font-medium truncate max-w-full">
                {participant.username}
                {participant.user_id === currentUserId && ' (You)'}
              </span>
            </div>
          ))}
        </div>

        {!isConnected && participants.length === 0 && (
          <div className="text-center text-muted-foreground py-8">
            No one is in this voice channel yet
          </div>
        )}
      </div>

      <div className="p-4 border-t border-border bg-card">
        {!isConnected ? (
          <Button onClick={() => setShowWarning(true)} className="w-full">
            Join Voice Channel
          </Button>
        ) : (
          <TooltipProvider>
            <div className="flex items-center justify-center gap-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant={isMuted ? 'destructive' : 'secondary'}
                    size="lg"
                    onClick={toggleMute}
                    className="h-12 w-12 rounded-full p-0"
                  >
                    {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{isMuted ? 'Unmute' : 'Mute'}</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant={isDeafened ? 'destructive' : 'secondary'}
                    size="lg"
                    onClick={toggleDeafen}
                    className="h-12 w-12 rounded-full p-0"
                  >
                    {isDeafened ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{isDeafened ? 'Undeafen' : 'Deafen'}</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant={isScreensharing ? 'default' : 'secondary'}
                    size="lg"
                    onClick={toggleScreenShare}
                    className="h-12 w-12 rounded-full p-0"
                  >
                    {isScreensharing ? <ScreenShareOff className="h-5 w-5" /> : <ScreenShare className="h-5 w-5" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{isScreensharing ? 'Stop Sharing' : 'Share Screen'}</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="destructive"
                    size="lg"
                    onClick={leaveChannel}
                    className="h-12 w-12 rounded-full p-0"
                  >
                    <PhoneOff className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Leave Channel</TooltipContent>
              </Tooltip>
            </div>
          </TooltipProvider>
        )}
      </div>

      {/* Voice Chat Warning Dialog */}
      <AlertDialog open={showWarning} onOpenChange={setShowWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-amber-500">
              <AlertTriangle className="h-5 w-5" />
              Voice Chat Warning
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <p>
                <strong>Please be aware:</strong> Voice chat is not moderated or censored. 
                Content in voice channels is not recorded or monitored.
              </p>
              <p>
                Exercise caution when sharing personal information and be mindful of who you're speaking with.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => { setShowWarning(false); joinChannel(); }}>
              I Understand, Join Voice
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
