import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Phone, PhoneOff, Mic, MicOff, Volume2, VolumeX } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface DMVoiceCallProps {
  dmChannelId: string
  currentUserId: string
  otherUserId: string
  otherUsername: string
}

interface CallState {
  isInCall: boolean
  isCalling: boolean
  isReceivingCall: boolean
  isMuted: boolean
  isDeafened: boolean
  callerId?: string
}

export function DMVoiceCall({ dmChannelId, currentUserId, otherUserId, otherUsername }: DMVoiceCallProps) {
  const [callState, setCallState] = useState<CallState>({
    isInCall: false,
    isCalling: false,
    isReceivingCall: false,
    isMuted: false,
    isDeafened: false,
  })
  const { toast } = useToast()
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null)

  useEffect(() => {
    // Set up presence channel for call signaling
    const channel = supabase.channel(`dm-call:${dmChannelId}`)
    channelRef.current = channel

    channel
      .on('broadcast', { event: 'call-request' }, ({ payload }) => {
        if (payload.targetUserId === currentUserId && payload.callerId !== currentUserId) {
          setCallState(prev => ({
            ...prev,
            isReceivingCall: true,
            callerId: payload.callerId
          }))
          toast({
            title: 'Incoming Call',
            description: `${otherUsername} is calling you`,
          })
        }
      })
      .on('broadcast', { event: 'call-accepted' }, ({ payload }) => {
        if (payload.targetUserId === currentUserId) {
          setCallState(prev => ({
            ...prev,
            isInCall: true,
            isCalling: false,
          }))
          startWebRTC(false)
        }
      })
      .on('broadcast', { event: 'call-rejected' }, ({ payload }) => {
        if (payload.targetUserId === currentUserId) {
          setCallState(prev => ({
            ...prev,
            isCalling: false,
          }))
          toast({
            title: 'Call Declined',
            description: `${otherUsername} declined the call`,
            variant: 'destructive'
          })
        }
      })
      .on('broadcast', { event: 'call-ended' }, ({ payload }) => {
        if (payload.targetUserId === currentUserId) {
          endCall()
          toast({
            title: 'Call Ended',
            description: 'The call has ended'
          })
        }
      })
      .on('broadcast', { event: 'webrtc-offer' }, async ({ payload }) => {
        if (payload.targetUserId === currentUserId && peerConnectionRef.current) {
          await peerConnectionRef.current.setRemoteDescription(payload.offer)
          const answer = await peerConnectionRef.current.createAnswer()
          await peerConnectionRef.current.setLocalDescription(answer)
          channel.send({
            type: 'broadcast',
            event: 'webrtc-answer',
            payload: { targetUserId: otherUserId, answer }
          })
        }
      })
      .on('broadcast', { event: 'webrtc-answer' }, async ({ payload }) => {
        if (payload.targetUserId === currentUserId && peerConnectionRef.current) {
          await peerConnectionRef.current.setRemoteDescription(payload.answer)
        }
      })
      .on('broadcast', { event: 'webrtc-ice-candidate' }, async ({ payload }) => {
        if (payload.targetUserId === currentUserId && peerConnectionRef.current) {
          await peerConnectionRef.current.addIceCandidate(payload.candidate)
        }
      })
      .subscribe()

    return () => {
      channel.unsubscribe()
      cleanup()
    }
  }, [dmChannelId, currentUserId, otherUserId])

  const cleanup = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close()
      peerConnectionRef.current = null
    }
  }

  const startWebRTC = async (isInitiator: boolean) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream

      const peerConnection = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
      })
      peerConnectionRef.current = peerConnection

      stream.getTracks().forEach(track => {
        peerConnection.addTrack(track, stream)
      })

      peerConnection.ontrack = (event) => {
        if (audioRef.current) {
          audioRef.current.srcObject = event.streams[0]
        }
      }

      peerConnection.onicecandidate = (event) => {
        if (event.candidate && channelRef.current) {
          channelRef.current.send({
            type: 'broadcast',
            event: 'webrtc-ice-candidate',
            payload: { targetUserId: otherUserId, candidate: event.candidate }
          })
        }
      }

      if (isInitiator) {
        const offer = await peerConnection.createOffer()
        await peerConnection.setLocalDescription(offer)
        channelRef.current?.send({
          type: 'broadcast',
          event: 'webrtc-offer',
          payload: { targetUserId: otherUserId, offer }
        })
      }
    } catch (error) {
      toast({
        title: 'Microphone Error',
        description: 'Could not access microphone',
        variant: 'destructive'
      })
      endCall()
    }
  }

  const startCall = async () => {
    setCallState(prev => ({ ...prev, isCalling: true }))
    
    channelRef.current?.send({
      type: 'broadcast',
      event: 'call-request',
      payload: { callerId: currentUserId, targetUserId: otherUserId }
    })

    toast({
      title: 'Calling...',
      description: `Calling ${otherUsername}`
    })

    // Timeout after 30 seconds
    setTimeout(() => {
      setCallState(prev => {
        if (prev.isCalling && !prev.isInCall) {
          toast({
            title: 'No Answer',
            description: `${otherUsername} didn't answer`,
            variant: 'destructive'
          })
          return { ...prev, isCalling: false }
        }
        return prev
      })
    }, 30000)
  }

  const acceptCall = () => {
    setCallState(prev => ({
      ...prev,
      isReceivingCall: false,
      isInCall: true,
    }))

    channelRef.current?.send({
      type: 'broadcast',
      event: 'call-accepted',
      payload: { targetUserId: callState.callerId }
    })

    startWebRTC(true)
  }

  const rejectCall = () => {
    channelRef.current?.send({
      type: 'broadcast',
      event: 'call-rejected',
      payload: { targetUserId: callState.callerId }
    })

    setCallState(prev => ({
      ...prev,
      isReceivingCall: false,
      callerId: undefined,
    }))
  }

  const endCall = () => {
    channelRef.current?.send({
      type: 'broadcast',
      event: 'call-ended',
      payload: { targetUserId: otherUserId }
    })

    cleanup()
    setCallState({
      isInCall: false,
      isCalling: false,
      isReceivingCall: false,
      isMuted: false,
      isDeafened: false,
    })
  }

  const toggleMute = () => {
    if (streamRef.current) {
      const audioTrack = streamRef.current.getAudioTracks()[0]
      if (audioTrack) {
        audioTrack.enabled = callState.isMuted
        setCallState(prev => ({ ...prev, isMuted: !prev.isMuted }))
      }
    }
  }

  const toggleDeafen = () => {
    if (audioRef.current) {
      audioRef.current.muted = !callState.isDeafened
      setCallState(prev => ({ ...prev, isDeafened: !prev.isDeafened }))
    }
  }

  return (
    <div className="flex items-center gap-2">
      <audio ref={audioRef} autoPlay />

      {/* Incoming call UI */}
      {callState.isReceivingCall && (
        <div className="flex items-center gap-2 animate-pulse">
          <Button
            size="sm"
            onClick={acceptCall}
            className="bg-green-600 hover:bg-green-700"
          >
            <Phone className="h-4 w-4 mr-1" />
            Accept
          </Button>
          <Button
            size="sm"
            variant="destructive"
            onClick={rejectCall}
          >
            <PhoneOff className="h-4 w-4 mr-1" />
            Decline
          </Button>
        </div>
      )}

      {/* In call controls */}
      {callState.isInCall && (
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant={callState.isMuted ? 'destructive' : 'secondary'}
            onClick={toggleMute}
            title={callState.isMuted ? 'Unmute' : 'Mute'}
          >
            {callState.isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </Button>
          <Button
            size="sm"
            variant={callState.isDeafened ? 'destructive' : 'secondary'}
            onClick={toggleDeafen}
            title={callState.isDeafened ? 'Undeafen' : 'Deafen'}
          >
            {callState.isDeafened ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </Button>
          <Button
            size="sm"
            variant="destructive"
            onClick={endCall}
            title="End Call"
          >
            <PhoneOff className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Start call button */}
      {!callState.isInCall && !callState.isReceivingCall && !callState.isCalling && (
        <Button
          size="sm"
          variant="ghost"
          onClick={startCall}
          className="text-green-500 hover:text-green-400 hover:bg-green-500/10"
          title={`Call ${otherUsername}`}
        >
          <Phone className="h-4 w-4" />
        </Button>
      )}

      {/* Calling indicator */}
      {callState.isCalling && (
        <Button
          size="sm"
          variant="destructive"
          onClick={endCall}
          className="animate-pulse"
        >
          <PhoneOff className="h-4 w-4 mr-1" />
          Cancel
        </Button>
      )}
    </div>
  )
}
