import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'

interface Profile {
  id: string
  username: string
  avatar_url?: string
  banner_url?: string
  bio?: string
  activity?: string
  activity_details?: string
}

interface DMProfileCardProps {
  profile: Profile
}

export function DMProfileCard({ profile }: DMProfileCardProps) {
  return (
    <div className="border-b border-border">
      {/* Banner */}
      <div 
        className="h-20 bg-gradient-to-r from-primary/30 to-primary/10"
        style={profile.banner_url ? { 
          backgroundImage: `url(${profile.banner_url})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        } : undefined}
      />
      
      {/* Profile info */}
      <div className="px-4 pb-4 -mt-8">
        <div className="flex items-end gap-3">
          <Avatar className="h-16 w-16 border-4 border-background">
            {profile.avatar_url ? (
              <AvatarImage src={profile.avatar_url} alt={profile.username} />
            ) : null}
            <AvatarFallback className="bg-primary text-primary-foreground text-xl font-bold">
              {profile.username.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0 pb-1">
            <h2 className="font-bold text-foreground truncate">{profile.username}</h2>
            {profile.activity && (
              <p className="text-xs text-muted-foreground truncate">
                {profile.activity} {profile.activity_details || ''}
              </p>
            )}
          </div>
        </div>
        
        {profile.bio && (
          <p className="mt-3 text-sm text-muted-foreground line-clamp-2">{profile.bio}</p>
        )}
      </div>
    </div>
  )
}
