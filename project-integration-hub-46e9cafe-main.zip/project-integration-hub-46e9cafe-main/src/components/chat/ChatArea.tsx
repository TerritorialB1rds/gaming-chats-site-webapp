import { useEffect, useState, useRef } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Send, Hash, AtSign } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { messageSchema } from '@/lib/validations'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { formatDistanceToNow } from 'date-fns'
import { getSafeErrorMessage, logError } from '@/lib/errorUtils'
import { useUserRole } from '@/hooks/useUserRole'
import { DMVoiceCall } from '@/components/voice/DMVoiceCall'
import { MessageReactions } from './MessageReactions'
import { FileUpload } from './FileUpload'
import { soundEffects } from '@/utils/soundEffects'
import { DMProfileCard } from './DMProfileCard'

const MIN_MESSAGE_INTERVAL = 1000

interface Message {
  id: string
  content: string
  user_id: string
  channel_id: string
  created_at: string
  image_url?: string
  profiles: { username: string; avatar_url?: string }
}

interface Profile {
  id: string
  username: string
  avatar_url?: string
  banner_url?: string
  bio?: string
  activity?: string
  activity_details?: string
}

interface ChatAreaProps {
  channelId: string
  currentUser: Profile
}

export function ChatArea({ channelId, currentUser }: ChatAreaProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(false)
  const [channelName, setChannelName] = useState('')
  const [lastSendTime, setLastSendTime] = useState(0)
  const [dmOtherUser, setDmOtherUser] = useState<Profile | null>(null)
  const [mentionSuggestions, setMentionSuggestions] = useState<{ id: string; username: string }[]>([])
  const [showMentions, setShowMentions] = useState(false)
  const [mentionQuery, setMentionQuery] = useState('')
  const [channelMembers, setChannelMembers] = useState<{ id: string; username: string }[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const { isAdmin } = useUserRole(currentUser.id)

  const isDM = channelId.startsWith('dm-')

  useEffect(() => {
    if (!isDM) {
      loadChannelName()
      loadChannelMembers()
    } else {
      loadDmOtherUser()
    }
    loadMessages()
    const cleanup = subscribeToMessages()
    return cleanup
  }, [channelId])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const loadChannelName = async () => {
    const { data } = await supabase.from('channels').select('name').eq('id', channelId).single()
    if (data) setChannelName(data.name)
  }

  const loadChannelMembers = async () => {
    const { data: profiles } = await supabase
      .from('profiles')
      .select('user_id, username')
      .eq('is_online', true)

    if (profiles) {
      setChannelMembers(profiles.map(p => ({ id: p.user_id, username: p.username || 'Unknown' })))
    }
  }

  const loadDmOtherUser = async () => {
    const fullId = channelId.replace('dm-', '')
    const otherUserId = fullId.includes(currentUser.id)
      ? fullId.replace(currentUser.id, '').replace('-', '').replace(/^-|-$/g, '')
      : null

    if (otherUserId) {
      const { data } = await supabase
        .from('profiles')
        .select('user_id, username, avatar_url, banner_url, bio, activity, activity_details')
        .eq('user_id', otherUserId)
        .single()

      if (data) {
        setDmOtherUser({ 
          id: data.user_id, 
          username: data.username || 'User',
          avatar_url: data.avatar_url || undefined,
          banner_url: data.banner_url || undefined,
          bio: data.bio || undefined,
          activity: data.activity || undefined,
          activity_details: data.activity_details || undefined
        })
        setChannelMembers([{ id: data.user_id, username: data.username || 'User' }])
      }
    }
  }

  const loadMessages = async () => {
    const { data: msgs } = await supabase
      .from('messages')
      .select('*')
      .eq('channel_id', channelId)
      .order('created_at', { ascending: true })
      .limit(50)

    if (!msgs) return

    const userIds = Array.from(new Set(msgs.map((m: any) => m.user_id)))
    const { data: profs } = await supabase.from('profiles').select('user_id, username, avatar_url').in('user_id', userIds)
    const map = new Map((profs ?? []).map((p: any) => [p.user_id, { username: p.username, avatar_url: p.avatar_url }]))
    const enriched = msgs.map((m: any) => ({ ...m, profiles: map.get(m.user_id) ?? { username: 'Unknown' } }))
    setMessages(enriched)
  }

  const subscribeToMessages = () => {
    const subscription = supabase
      .channel(`messages:${channelId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, async (payload) => {
        if (payload.new.channel_id !== channelId) return
        const { data: profile } = await supabase.from('profiles').select('username, avatar_url').eq('user_id', payload.new.user_id).single()
        const newMessage = { ...payload.new, profiles: profile ?? { username: 'Unknown' } } as Message
        setMessages(prev => [...prev, newMessage])

        // Play sound if message is from another user
        if (payload.new.user_id !== currentUser.id) {
          // Check if mentioned
          if (payload.new.content.includes(`@${currentUser.username}`)) {
            soundEffects.playMentionSound()
          } else if (isDM) {
            soundEffects.playMessageSound()
          }
        }
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, (payload) => {
        setMessages(prev => prev.filter(m => m.id !== payload.old.id))
      })
      .subscribe()
    return () => { supabase.removeChannel(subscription) }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setNewMessage(value)

    // Check for @mention
    const match = value.match(/@(\w*)$/)
    if (match) {
      const query = match[1].toLowerCase()
      setMentionQuery(query)
      const filtered = channelMembers.filter(m =>
        m.username.toLowerCase().includes(query) && m.id !== currentUser.id
      )
      setMentionSuggestions(filtered.slice(0, 5))
      setShowMentions(filtered.length > 0)
    } else {
      setShowMentions(false)
    }
  }

  const insertMention = (username: string) => {
    const newValue = newMessage.replace(/@\w*$/, `@${username} `)
    setNewMessage(newValue)
    setShowMentions(false)
    inputRef.current?.focus()
  }

  const handleAdminCommand = async (command: string): Promise<boolean> => {
    if (!isAdmin) return false

    const parts = command.slice(1).split(' ')
    const cmd = parts[0].toLowerCase()
    const arg = parts.slice(1).join(' ')

    if (cmd === 'kick' && arg) {
      const { data: targetUser } = await supabase
        .from('profiles')
        .select('user_id, username')
        .eq('username', arg)
        .single()

      if (!targetUser) {
        toast({ title: 'User not found', description: `Could not find user "${arg}"`, variant: 'destructive' })
        return true
      }

      await supabase
        .from('profiles')
        .update({ is_online: false })
        .eq('user_id', targetUser.user_id)

      toast({ title: 'User kicked', description: `${arg} has been kicked from the chat` })
      return true
    }

    if (cmd === 'clearchat') {
      const { error } = await supabase
        .from('messages')
        .delete()
        .eq('channel_id', channelId)

      if (error) {
        toast({ title: 'Error', description: 'Failed to clear chat', variant: 'destructive' })
      } else {
        setMessages([])
        toast({ title: 'Chat cleared', description: 'All messages have been removed' })
      }
      return true
    }

    return false
  }

  const handleFileUpload = async (url: string, type: 'image' | 'video' | 'gif') => {
    setLoading(true)
    try {
      const { error } = await supabase.from('messages').insert({
        content: type === 'video' ? '[Video]' : type === 'gif' ? '[GIF]' : '[Image]',
        user_id: currentUser.id,
        channel_id: channelId,
        image_url: url
      })
      if (error) throw error
    } catch (error) {
      logError(error, 'handleFileUpload')
      toast({ title: 'Error', description: 'Failed to send file', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    if (newMessage.startsWith('/')) {
      const handled = await handleAdminCommand(newMessage.trim())
      if (handled) {
        setNewMessage('')
        return
      }
    }

    const now = Date.now()
    if (now - lastSendTime < MIN_MESSAGE_INTERVAL) {
      toast({ title: 'Please wait', description: 'You are sending messages too quickly', variant: 'destructive' })
      return
    }

    setLoading(true)

    try {
      const validation = messageSchema.safeParse({ content: newMessage.trim() })
      if (!validation.success) {
        toast({ title: 'Invalid message', description: validation.error.errors[0].message, variant: 'destructive' })
        return
      }

      // Check for mentions and create notifications
      const mentionMatches = newMessage.match(/@(\w+)/g)
      if (mentionMatches) {
        for (const mention of mentionMatches) {
          const username = mention.slice(1)
          const { data: mentionedUser } = await supabase
            .from('profiles')
            .select('user_id')
            .eq('username', username)
            .single()

          if (mentionedUser && mentionedUser.user_id !== currentUser.id) {
            await supabase.from('notifications').insert({
              user_id: mentionedUser.user_id,
              from_user_id: currentUser.id,
              type: 'mention',
              content: `mentioned you in ${isDM ? 'a DM' : `#${channelName}`}`,
              channel_id: channelId
            })
          }
        }
      }

      const { error } = await supabase.from('messages').insert({
        content: validation.data.content,
        user_id: currentUser.id,
        channel_id: channelId,
      })
      if (error) throw error
      setNewMessage('')
      setLastSendTime(now)
    } catch (error: unknown) {
      logError(error, 'sendMessage')
      toast({ title: 'Error', description: getSafeErrorMessage(error, 'message'), variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const renderMessageContent = (message: Message) => {
    // Parse @mentions and make them highlighted
    const content = message.content.replace(
      /@(\w+)/g,
      '<span class="bg-primary/20 text-primary px-1 rounded">@$1</span>'
    )

    return (
      <div>
        <p
          className="text-sm text-foreground/90 break-words"
          dangerouslySetInnerHTML={{ __html: content }}
        />
        {message.image_url && (
          <div className="mt-2 max-w-md">
            {message.image_url.includes('.mp4') || message.image_url.includes('.webm') || message.image_url.includes('.mov') ? (
              <video
                src={message.image_url}
                controls
                className="rounded-lg max-h-80 w-auto"
              />
            ) : (
              <img
                src={message.image_url}
                alt="Uploaded content"
                className="rounded-lg max-h-80 w-auto cursor-pointer hover:opacity-90 transition-opacity"
                onClick={() => window.open(message.image_url, '_blank')}
              />
            )}
          </div>
        )}
      </div>
    )
  }

  const displayName = isDM ? (dmOtherUser?.username || 'Direct Message') : (channelName || channelId)

  return (
    <div className="flex flex-col h-full max-h-screen">
      <div className="h-12 px-4 flex items-center gap-2 border-b border-border shadow-sm bg-background shrink-0">
        {isDM ? <AtSign className="h-5 w-5 text-muted-foreground" /> : <Hash className="h-5 w-5 text-muted-foreground" />}
        <span className="font-display font-semibold">{displayName}</span>

        {isDM && dmOtherUser && (
          <div className="ml-auto">
            <DMVoiceCall
              dmChannelId={channelId}
              currentUserId={currentUser.id}
              otherUserId={dmOtherUser.id}
              otherUsername={dmOtherUser.username}
            />
          </div>
        )}
      </div>

      <ScrollArea className="flex-1 min-h-0">
        {/* DM Profile Card */}
        {isDM && dmOtherUser && (
          <DMProfileCard profile={dmOtherUser} />
        )}
        
        <div className="px-4 py-4 space-y-3">
          {messages.map((message) => (
            <div key={message.id} className="flex gap-3 py-1 group hover:bg-secondary/30 rounded-md px-2 transition-colors">
              <Avatar className="h-10 w-10 mt-0.5 shrink-0">
                {message.profiles.avatar_url ? (
                  <AvatarImage src={message.profiles.avatar_url} alt={message.profiles.username} />
                ) : null}
                <AvatarFallback className="bg-primary text-primary-foreground text-sm font-medium">
                  {message.profiles.username.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2 flex-wrap">
                  <span className="font-medium text-sm text-foreground">{message.profiles.username}</span>
                  <span className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(message.created_at), { addSuffix: true })}</span>
                </div>
                {renderMessageContent(message)}
                <MessageReactions messageId={message.id} currentUserId={currentUser.id} />
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <div className="px-4 pb-4 pt-2 relative shrink-0 bg-background safe-area-bottom">
        {showMentions && (
          <div className="absolute bottom-full left-4 right-4 mb-2 bg-popover border border-border rounded-lg shadow-lg overflow-hidden max-h-40 overflow-y-auto">
            {mentionSuggestions.map((user) => (
              <button
                key={user.id}
                onClick={() => insertMention(user.username)}
                className="w-full px-3 py-2 text-left hover:bg-secondary/50 flex items-center gap-2 text-sm"
              >
                <span className="text-primary">@</span>
                <span>{user.username}</span>
              </button>
            ))}
          </div>
        )}

        <form onSubmit={sendMessage} className="flex items-center gap-2 bg-input rounded-lg px-3 py-2">
          <FileUpload currentUserId={currentUser.id} onUpload={handleFileUpload} />
          <Input
            ref={inputRef}
            placeholder={`Message ${isDM ? '@' : '#'}${displayName}`}
            value={newMessage}
            onChange={handleInputChange}
            disabled={loading}
            className="flex-1 bg-transparent border-0 focus-visible:ring-0 px-0 placeholder:text-muted-foreground text-base"
          />
          <Button type="submit" size="sm" disabled={loading || !newMessage.trim()} className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-md px-3 shrink-0">
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  )
}
