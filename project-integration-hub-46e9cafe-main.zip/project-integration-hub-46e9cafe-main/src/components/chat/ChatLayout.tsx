import { useEffect, useState } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { Sidebar } from './Sidebar'
import { ChatArea } from './ChatArea'
import { VoiceChannel } from '@/components/voice/VoiceChannel'
import { Button } from '@/components/ui/button'
import { LogOut, Shield, Settings } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { useUserRole } from '@/hooks/useUserRole'
import { FloatingAdminPanel } from '@/components/admin/FloatingAdminPanel'
import { ProfileCustomization } from '@/components/profile/ProfileCustomization'
import { NotificationCenter } from '@/components/notifications/NotificationCenter'
import { InstallPWA } from '@/components/pwa/InstallPWA'
import { OfflineIndicator } from '@/components/pwa/OfflineIndicator'

interface Profile {
  id: string
  username: string
  avatar_url?: string
  bio?: string
  pronouns?: string
  banner_url?: string
  activity?: string
  activity_details?: string
  is_online: boolean
  banned_at?: string | null
}

export function ChatLayout() {
  const [currentUser, setCurrentUser] = useState<Profile | null>(null)
  const [selectedChannel, setSelectedChannel] = useState<string | null>(null)
  const [selectedChannelType, setSelectedChannelType] = useState<'text' | 'voice' | 'dm'>('text')
  const [selectedChannelName, setSelectedChannelName] = useState<string>('')
  const [adminPanelOpen, setAdminPanelOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const { toast } = useToast()
  const { isAdmin } = useUserRole(currentUser?.id)

  useEffect(() => {
    getCurrentUser()
  }, [])

  const getCurrentUser = async () => {
    try {
      const { data: { user }, error: userErr } = await supabase.auth.getUser()
      if (userErr) console.error('getUser error', userErr)
      if (!user) return

      const { data: profile, error: profileErr } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle()

      let ensuredProfile = profile as Profile | null

      // Check if user is banned
      if (ensuredProfile?.banned_at) {
        await supabase.auth.signOut()
        toast({
          title: 'Account Banned',
          description: 'Your account has been banned.',
          variant: 'destructive'
        })
        return
      }

      if (!ensuredProfile) {
        const fallbackUsername = (user.user_metadata?.username as string) || (user.email?.split('@')[0] ?? 'user')
        const { data: created, error: createErr } = await supabase
          .from('profiles')
          .insert({ user_id: user.id, username: fallbackUsername, is_online: true })
          .select('*')
          .single()
        if (createErr) {
          console.error('Create profile error', createErr)
        } else {
          ensuredProfile = { ...created, id: user.id } as Profile
        }
      } else {
        await supabase.from('profiles').update({ is_online: true }).eq('user_id', user.id)
        ensuredProfile = { ...ensuredProfile, id: user.id }
      }

      if (ensuredProfile) setCurrentUser(ensuredProfile)

      const { data: general } = await supabase
        .from('channels')
        .select('id')
        .eq('name', 'general')
        .eq('type', 'text')
        .eq('is_private', false)
        .maybeSingle()

      if (general?.id) {
        setSelectedChannel(general.id)
      } else {
        const { data: firstChannel } = await supabase
          .from('channels')
          .select('id')
          .eq('type', 'text')
          .eq('is_private', false)
          .order('created_at')
          .limit(1)
          .maybeSingle()

        if (firstChannel?.id) {
          setSelectedChannel(firstChannel.id)
        }
      }
    } catch (e) {
      console.error('getCurrentUser fatal', e)
    }
  }

  const handleChannelSelect = async (channelId: string, channelType?: 'text' | 'voice' | 'dm') => {
    setSelectedChannel(channelId)
    setSelectedChannelType(channelType || 'text')

    if (channelType === 'voice') {
      const { data } = await supabase
        .from('channels')
        .select('name')
        .eq('id', channelId)
        .single()
      setSelectedChannelName(data?.name || 'Voice Channel')
    }
  }

  const handleLogout = async () => {
    if (currentUser) {
      await supabase
        .from('profiles')
        .update({ is_online: false })
        .eq('user_id', currentUser.id)
    }

    await supabase.auth.signOut()
    toast({
      title: 'Logged out',
      description: 'See you next time!',
    })
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <div className="h-[100dvh] flex flex-col md:flex-row bg-background overflow-hidden">
      {/* Offline indicator */}
      <OfflineIndicator />

      {/* Mobile header */}
      <div className="md:hidden flex items-center justify-between px-4 py-2 bg-card border-b border-border shrink-0">
        <h1 className="font-display font-extrabold text-base text-foreground">Gaming Chats</h1>
        <div className="flex items-center gap-2">
          <InstallPWA />
          <NotificationCenter
            currentUserId={currentUser.id}
            onNotificationClick={(channelId) => {
              setSelectedChannel(channelId)
              setSelectedChannelType(channelId.startsWith('dm-') ? 'dm' : 'text')
            }}
          />
          {isAdmin && (
            <button
              onClick={() => setAdminPanelOpen(!adminPanelOpen)}
              className="p-2 rounded-lg bg-primary/20 text-primary"
              title="Admin Panel"
            >
              <Shield className="h-5 w-5" />
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-1 min-h-0">
        {/* Server list - narrow icon bar (hidden on mobile) */}
        <div className="hidden md:flex w-[72px] bg-sidebar-background flex-col items-center py-3 gap-2 shrink-0">
          {/* Server icon */}
          <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center text-primary-foreground font-display font-bold text-lg hover:rounded-xl transition-all duration-200 cursor-pointer">
            GC
          </div>
          <div className="w-8 h-0.5 bg-border rounded-full my-1" />

          {/* Notifications */}
          <NotificationCenter
            currentUserId={currentUser.id}
            onNotificationClick={(channelId) => {
              setSelectedChannel(channelId)
              setSelectedChannelType(channelId.startsWith('dm-') ? 'dm' : 'text')
            }}
          />

          {/* Admin panel toggle */}
          {isAdmin && (
            <button
              onClick={() => setAdminPanelOpen(!adminPanelOpen)}
              className="w-12 h-12 rounded-[24px] hover:rounded-xl transition-all duration-200 flex items-center justify-center bg-primary/20 text-primary hover:bg-primary hover:text-primary-foreground"
              title="Admin Panel"
            >
              <Shield className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* Channel sidebar */}
        <div className="w-full md:w-60 bg-card flex flex-col shrink-0">
          {/* Server header (hidden on mobile - shown in mobile header above) */}
          <div className="hidden md:flex h-12 px-4 items-center justify-between border-b border-border shadow-sm">
            <h1 className="font-display font-extrabold text-base text-foreground tracking-tight">
              Gaming Chats
            </h1>
            <InstallPWA />
          </div>

          <Sidebar
            currentUser={currentUser}
            selectedChannel={selectedChannel}
            onChannelSelect={handleChannelSelect}
          />

          {/* User area */}
          <div className="mt-auto bg-sidebar-background px-2 py-2 shrink-0">
            <div className="flex items-center gap-2 p-1.5 rounded-md hover:bg-secondary/50 transition-colors">
              <div className="relative shrink-0">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium overflow-hidden">
                  {currentUser.avatar_url ? (
                    <img src={currentUser.avatar_url} alt={currentUser.username} className="w-full h-full object-cover" />
                  ) : (
                    currentUser.username.charAt(0).toUpperCase()
                  )}
                </div>
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-sidebar-background" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground truncate">{currentUser.username}</div>
                <div className="text-xs text-muted-foreground truncate">
                  {currentUser.activity ? `${currentUser.activity} ${currentUser.activity_details || ''}` : 'Online'}
                </div>
              </div>
              <div className="ml-auto flex gap-0.5 shrink-0">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setProfileOpen(true)}
                  className="h-8 w-8 p-0 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary"
                  title="Edit Profile"
                >
                  <Settings className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="h-8 w-8 p-0 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary"
                  title="Logout"
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main content area */}
        <div className="hidden md:flex flex-1 flex-col bg-background min-w-0">
          {selectedChannel ? (
            selectedChannelType === 'voice' ? (
              <VoiceChannel
                channelId={selectedChannel}
                channelName={selectedChannelName}
                currentUserId={currentUser.id}
                currentUsername={currentUser.username}
              />
            ) : (
              <ChatArea
                channelId={selectedChannel}
                currentUser={currentUser}
              />
            )
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              <div className="text-center animate-fade-in">
                <p className="text-lg mb-2 font-display font-semibold">No channels available</p>
                <p className="text-sm">Create a channel to get started</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Floating Admin Panel */}
      <FloatingAdminPanel
        isOpen={adminPanelOpen}
        onClose={() => setAdminPanelOpen(false)}
        currentUserId={currentUser.id}
      />

      {/* Profile Customization Dialog */}
      {currentUser && (
        <ProfileCustomization
          isOpen={profileOpen}
          onClose={() => setProfileOpen(false)}
          profile={currentUser}
          onUpdate={(updated) => setCurrentUser(updated as Profile)}
        />
      )}
    </div>
  )
}
