import { useState, useEffect } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { SmilePlus } from 'lucide-react'

interface Reaction {
  emoji: string
  count: number
  userReacted: boolean
}

interface MessageReactionsProps {
  messageId: string
  currentUserId: string
}

const EMOJI_OPTIONS = ['👍', '❤️', '😂', '😮', '😢', '😡', '🔥', '👏', '🎉', '💯']

export function MessageReactions({ messageId, currentUserId }: MessageReactionsProps) {
  const [reactions, setReactions] = useState<Reaction[]>([])
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    loadReactions()
    const subscription = supabase
      .channel(`reactions:${messageId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'message_reactions', filter: `message_id=eq.${messageId}` }, () => {
        loadReactions()
      })
      .subscribe()

    return () => { supabase.removeChannel(subscription) }
  }, [messageId])

  const loadReactions = async () => {
    const { data } = await supabase
      .from('message_reactions')
      .select('emoji, user_id')
      .eq('message_id', messageId)

    if (!data) return

    const emojiMap = new Map<string, { count: number; userReacted: boolean }>()
    data.forEach(r => {
      const existing = emojiMap.get(r.emoji) || { count: 0, userReacted: false }
      existing.count++
      if (r.user_id === currentUserId) existing.userReacted = true
      emojiMap.set(r.emoji, existing)
    })

    setReactions(Array.from(emojiMap.entries()).map(([emoji, data]) => ({
      emoji,
      count: data.count,
      userReacted: data.userReacted
    })))
  }

  const toggleReaction = async (emoji: string) => {
    const existing = reactions.find(r => r.emoji === emoji && r.userReacted)

    if (existing) {
      await supabase
        .from('message_reactions')
        .delete()
        .eq('message_id', messageId)
        .eq('user_id', currentUserId)
        .eq('emoji', emoji)
    } else {
      await supabase
        .from('message_reactions')
        .insert({ message_id: messageId, user_id: currentUserId, emoji })
    }

    setIsOpen(false)
  }

  return (
    <div className="flex items-center gap-1 flex-wrap mt-1">
      {reactions.map((reaction) => (
        <button
          key={reaction.emoji}
          onClick={() => toggleReaction(reaction.emoji)}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs transition-colors ${
            reaction.userReacted
              ? 'bg-primary/20 text-primary border border-primary/30'
              : 'bg-secondary/50 text-muted-foreground hover:bg-secondary'
          }`}
        >
          <span>{reaction.emoji}</span>
          <span>{reaction.count}</span>
        </button>
      ))}

      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <SmilePlus className="h-4 w-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-2" side="top">
          <div className="flex gap-1 flex-wrap max-w-[200px]">
            {EMOJI_OPTIONS.map((emoji) => (
              <button
                key={emoji}
                onClick={() => toggleReaction(emoji)}
                className="p-1.5 hover:bg-secondary rounded text-lg transition-colors"
              >
                {emoji}
              </button>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
