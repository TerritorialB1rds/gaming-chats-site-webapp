import { useState, useRef } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { ImagePlus, FileVideo, Loader2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface FileUploadProps {
  currentUserId: string
  onUpload: (url: string, type: 'image' | 'video' | 'gif') => void
}

const MAX_FILE_SIZE = 10 * 1024 * 1024 // 10MB
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime']

export function FileUpload({ currentUserId, onUpload }: FileUploadProps) {
  const [uploading, setUploading] = useState(false)
  const imageInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      toast({
        title: 'File too large',
        description: 'Maximum file size is 10MB',
        variant: 'destructive'
      })
      return
    }

    // Validate file type
    const allowedTypes = type === 'image' ? ALLOWED_IMAGE_TYPES : ALLOWED_VIDEO_TYPES
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: 'Invalid file type',
        description: `Only ${type === 'image' ? 'JPEG, PNG, GIF, WebP' : 'MP4, WebM, MOV'} files are allowed`,
        variant: 'destructive'
      })
      return
    }

    setUploading(true)

    try {
      const fileExt = file.name.split('.').pop()
      const fileName = `${currentUserId}/${Date.now()}.${fileExt}`

      const { error: uploadError } = await supabase.storage
        .from('uploads')
        .upload(fileName, file)

      if (uploadError) throw uploadError

      const { data: { publicUrl } } = supabase.storage
        .from('uploads')
        .getPublicUrl(fileName)

      const fileType = file.type === 'image/gif' ? 'gif' : type
      onUpload(publicUrl, fileType)

      toast({ title: 'File uploaded successfully' })
    } catch (error) {
      console.error('Upload error:', error)
      toast({
        title: 'Upload failed',
        description: 'Could not upload file',
        variant: 'destructive'
      })
    } finally {
      setUploading(false)
      // Reset inputs
      if (imageInputRef.current) imageInputRef.current.value = ''
      if (videoInputRef.current) videoInputRef.current.value = ''
    }
  }

  return (
    <div className="flex items-center gap-1">
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFileSelect(e, 'image')}
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={(e) => handleFileSelect(e, 'video')}
      />

      <Button
        type="button"
        variant="ghost"
        size="sm"
        disabled={uploading}
        onClick={() => imageInputRef.current?.click()}
        className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
        title="Upload image or GIF"
      >
        {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}
      </Button>

      <Button
        type="button"
        variant="ghost"
        size="sm"
        disabled={uploading}
        onClick={() => videoInputRef.current?.click()}
        className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
        title="Upload video"
      >
        <FileVideo className="h-4 w-4" />
      </Button>
    </div>
  )
}
