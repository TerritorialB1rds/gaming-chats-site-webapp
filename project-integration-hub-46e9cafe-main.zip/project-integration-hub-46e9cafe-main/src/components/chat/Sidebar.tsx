import { useEffect, useState } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Hash, Volume2, ChevronDown, Plus, Lock } from 'lucide-react'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import { CreateChannelDialog } from './CreateChannelDialog'

interface Profile {
  id: string
  username: string
  avatar_url?: string
  is_online: boolean
}

interface Channel {
  id: string
  name: string
  type: 'text' | 'voice'
  created_by: string
  is_private: boolean
  join_code?: string
}

interface SidebarProps {
  currentUser: Profile
  selectedChannel: string | null
  onChannelSelect: (channelId: string, channelType?: 'text' | 'voice' | 'dm') => void
}

export function Sidebar({ currentUser, selectedChannel, onChannelSelect }: SidebarProps) {
  const [channels, setChannels] = useState<Channel[]>([])
  const [onlineUsers, setOnlineUsers] = useState<Profile[]>([])
  const [textChannelsOpen, setTextChannelsOpen] = useState(true)
  const [voiceChannelsOpen, setVoiceChannelsOpen] = useState(true)
  const [dmOpen, setDmOpen] = useState(true)
  const [createDialog, setCreateDialog] = useState<{
    isOpen: boolean
    type: 'text' | 'voice'
  }>({
    isOpen: false,
    type: 'text'
  })

  useEffect(() => {
    loadChannels()
    loadOnlineUsers()

    const channelSubscription = supabase
      .channel('channels')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'channels' },
        () => loadChannels()
      )
      .subscribe()

    const profileSubscription = supabase
      .channel('profiles')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'profiles' },
        () => loadOnlineUsers()
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channelSubscription)
      supabase.removeChannel(profileSubscription)
    }
  }, [])

  const loadChannels = async () => {
    const { data } = await supabase
      .from('channels')
      .select('*')
      .order('created_at')

    if (data) {
      setChannels(data as unknown as Channel[])
    }
  }

  const loadOnlineUsers = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('is_online', true)
      .neq('user_id', currentUser.id)

    if (data) {
      setOnlineUsers(data.map(d => ({ ...d, id: d.user_id })) as Profile[])
    }
  }

  const openCreateDialog = (type: 'text' | 'voice') => {
    setCreateDialog({ isOpen: true, type })
  }

  const textChannels = channels.filter(c => c.type === 'text')
  const voiceChannels = channels.filter(c => c.type === 'voice')

  return (
    <ScrollArea className="flex-1">
      <div className="px-2 py-3 space-y-4">
        {/* Text Channels */}
        <Collapsible open={textChannelsOpen} onOpenChange={setTextChannelsOpen}>
          <div className="flex items-center justify-between px-1 mb-1">
            <CollapsibleTrigger className="flex items-center gap-0.5 text-xs font-semibold text-muted-foreground uppercase tracking-wide hover:text-foreground transition-colors">
              <ChevronDown className={`h-3 w-3 transition-transform ${textChannelsOpen ? '' : '-rotate-90'}`} />
              Text Channels
            </CollapsibleTrigger>
            <button
              onClick={() => openCreateDialog('text')}
              className="p-1 text-muted-foreground hover:text-foreground transition-colors rounded shrink-0"
              title="Create Channel"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
          <CollapsibleContent className="space-y-0.5">
            {textChannels.map((channel) => (
              <button
                key={channel.id}
                onClick={() => onChannelSelect(channel.id, 'text')}
                className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm transition-colors group ${
                  selectedChannel === channel.id
                    ? 'bg-secondary text-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                }`}
              >
                {channel.is_private ? (
                  <Lock className="h-4 w-4 shrink-0 opacity-60" />
                ) : (
                  <Hash className="h-4 w-4 shrink-0 opacity-60" />
                )}
                <span className="truncate flex-1 text-left">{channel.name}</span>
              </button>
            ))}
          </CollapsibleContent>
        </Collapsible>

        {/* Voice Channels */}
        <Collapsible open={voiceChannelsOpen} onOpenChange={setVoiceChannelsOpen}>
          <div className="flex items-center justify-between px-1 mb-1">
            <CollapsibleTrigger className="flex items-center gap-0.5 text-xs font-semibold text-muted-foreground uppercase tracking-wide hover:text-foreground transition-colors">
              <ChevronDown className={`h-3 w-3 transition-transform ${voiceChannelsOpen ? '' : '-rotate-90'}`} />
              Voice Channels
            </CollapsibleTrigger>
            <button
              onClick={() => openCreateDialog('voice')}
              className="p-1 text-muted-foreground hover:text-foreground transition-colors rounded shrink-0"
              title="Create Channel"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
          <CollapsibleContent className="space-y-0.5">
            {voiceChannels.map((channel) => (
              <button
                key={channel.id}
                onClick={() => onChannelSelect(channel.id, 'voice')}
                className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm transition-colors ${
                  selectedChannel === channel.id
                    ? 'bg-secondary text-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                }`}
              >
                <Volume2 className="h-4 w-4 shrink-0 opacity-60" />
                <span className="truncate flex-1 text-left">{channel.name}</span>
                {channel.is_private && <Lock className="h-3 w-3 shrink-0 opacity-50" />}
              </button>
            ))}
          </CollapsibleContent>
        </Collapsible>

        {/* Direct Messages */}
        <Collapsible open={dmOpen} onOpenChange={setDmOpen}>
          <div className="flex items-center px-1 mb-1">
            <CollapsibleTrigger className="flex items-center gap-0.5 text-xs font-semibold text-muted-foreground uppercase tracking-wide hover:text-foreground transition-colors">
              <ChevronDown className={`h-3 w-3 transition-transform ${dmOpen ? '' : '-rotate-90'}`} />
              Direct Messages
            </CollapsibleTrigger>
          </div>
          <CollapsibleContent className="space-y-0.5">
            {/* Current user status */}
            <div className="flex items-center gap-2 px-2 py-1.5 text-sm">
              <div className="relative">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium">
                  {currentUser.username.charAt(0).toUpperCase()}
                </div>
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-card" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-foreground truncate">{currentUser.username}</div>
                <div className="text-xs text-muted-foreground">Online</div>
              </div>
            </div>

            {/* Online users */}
            {onlineUsers.map((user) => {
              const sortedIds = [currentUser.id, user.id].sort()
              const dmChannelId = `dm-${sortedIds[0]}-${sortedIds[1]}`

              return (
                <button
                  key={user.id}
                  onClick={() => onChannelSelect(dmChannelId, 'dm')}
                  className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm transition-colors ${
                    selectedChannel === dmChannelId
                      ? 'bg-secondary text-foreground'
                      : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                  }`}
                >
                  <div className="relative">
                    <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs font-medium">
                      {user.username.charAt(0).toUpperCase()}
                    </div>
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-card" />
                  </div>
                  <span className="truncate">{user.username}</span>
                </button>
              )
            })}
          </CollapsibleContent>
        </Collapsible>
      </div>

      <CreateChannelDialog
        isOpen={createDialog.isOpen}
        onClose={() => setCreateDialog({ isOpen: false, type: 'text' })}
        channelType={createDialog.type}
        userId={currentUser.id}
      />
    </ScrollArea>
  )
}
