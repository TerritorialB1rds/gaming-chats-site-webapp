import { useAuth } from '@/hooks/useAuth';
import { useSecurityCheck } from '@/hooks/useSecurityCheck';
import { AuthForm } from '@/components/auth/AuthForm';
import { SecurityBlockedScreen } from '@/components/auth/SecurityBlockedScreen';
import { ChatLayout } from '@/components/chat/ChatLayout';

const Index = () => {
  const { user, loading } = useAuth();
  const { isSecure, violations, checking } = useSecurityCheck();

  // Show loading while checking auth or security
  if (loading || checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-subtle">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-10 w-10 border-3 border-primary border-t-transparent rounded-full" />
          <span className="text-muted-foreground text-sm animate-pulse">
            {checking ? 'Running security checks...' : 'Loading...'}
          </span>
        </div>
      </div>
    );
  }

  // Block access if security check failed
  if (!isSecure) {
    return (
      <SecurityBlockedScreen
        violations={violations}
        onRetry={() => window.location.reload()}
      />
    );
  }

  if (!user) {
    return <AuthForm />;
  }

  return <ChatLayout />;
};

export default Index;
