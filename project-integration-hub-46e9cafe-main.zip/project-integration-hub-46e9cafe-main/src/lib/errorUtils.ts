/**
 * Error sanitization utilities to prevent information leakage
 * Maps internal error codes to user-friendly messages
 */

// Map of Postgres/Supabase error codes to safe user messages
const ERROR_CODE_MAP: Record<string, string> = {
  // Postgres constraint errors
  '23505': 'This item already exists',
  '23503': 'Referenced item not found', 
  '23502': 'Required field is missing',
  '23514': 'Input validation failed',
  
  // Permission/RLS errors
  '42501': 'Permission denied',
  '42000': 'Permission denied',
  'PGRST301': 'Permission denied',
  
  // Auth errors (safe to show)
  'invalid_credentials': 'Invalid username or password',
  'user_already_exists': 'An account with this username already exists',
  'email_not_confirmed': 'Please confirm your email address',
  
  // Rate limiting
  '429': 'Too many requests. Please wait a moment.',
  
  // Generic database errors
  '22P02': 'Invalid input format',
  '22001': 'Input is too long',
};

// Auth error message patterns that are safe to show
const SAFE_AUTH_PATTERNS = [
  /invalid.*password/i,
  /user.*not.*found/i,
  /email.*already.*registered/i,
  /password.*too.*weak/i,
  /invalid.*email/i,
];

export function getSafeErrorMessage(error: unknown, context?: string): string {
  if (!error) {
    return 'An unexpected error occurred. Please try again.';
  }

  // Handle Error objects
  if (error instanceof Error) {
    const errorWithCode = error as Error & { code?: string; status?: number };
    
    // Check if it's a known error code
    if (errorWithCode.code && ERROR_CODE_MAP[errorWithCode.code]) {
      return ERROR_CODE_MAP[errorWithCode.code];
    }
    
    // Check for safe auth patterns
    if (SAFE_AUTH_PATTERNS.some(pattern => pattern.test(errorWithCode.message))) {
      return errorWithCode.message;
    }
    
    // Check status code
    if (errorWithCode.status && ERROR_CODE_MAP[String(errorWithCode.status)]) {
      return ERROR_CODE_MAP[String(errorWithCode.status)];
    }
  }

  // Handle Supabase-style error objects
  if (typeof error === 'object' && error !== null) {
    const errObj = error as Record<string, unknown>;
    
    // Check for error code
    if (errObj.code && typeof errObj.code === 'string' && ERROR_CODE_MAP[errObj.code]) {
      return ERROR_CODE_MAP[errObj.code];
    }
    
    // Check for message with safe patterns
    if (errObj.message && typeof errObj.message === 'string') {
      if (SAFE_AUTH_PATTERNS.some(pattern => pattern.test(errObj.message as string))) {
        return errObj.message as string;
      }
    }
  }

  // Log full error for debugging (only in development)
  if (import.meta.env.DEV) {
    console.error('Full error details:', error);
  }

  // Return context-specific generic message
  switch (context) {
    case 'auth':
      return 'Authentication failed. Please check your credentials.';
    case 'message':
      return 'Failed to send message. Please try again.';
    case 'channel':
      return 'Failed to complete channel operation. Please try again.';
    default:
      return 'An error occurred. Please try again.';
  }
}

/**
 * Log error safely - full details in dev, minimal in production
 */
export function logError(error: unknown, context: string): void {
  if (import.meta.env.DEV) {
    console.error(`[${context}] Error:`, error);
  } else {
    // In production, log minimal info
    console.error(`[${context}] An error occurred`);
  }
}
