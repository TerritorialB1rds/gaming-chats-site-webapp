import { z } from 'zod'
import { Filter } from 'bad-words'

// Initialize profanity filter
const profanityFilter = new Filter()

// Custom word list - add any additional words you want to filter
profanityFilter.addWords('slur1', 'slur2')

// Authentication validation
export const authSchema = z.object({
  username: z.string()
    .min(3, 'Username must be at least 3 characters')
    .max(20, 'Username must be less than 20 characters')
    .regex(/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers, and underscores')
    .trim(),
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .max(100, 'Password must be less than 100 characters')
})

// Message validation with profanity check
export const messageSchema = z.object({
  content: z.string()
    .max(2000, 'Message is too long (max 2000 characters)')
    .trim()
    .refine((val) => !profanityFilter.isProfane(val), {
      message: 'Your message contains inappropriate language'
    })
})

// Clean message content
export const cleanMessage = (content: string): string => {
  return profanityFilter.clean(content)
}

// Check if content contains profanity
export const containsProfanity = (content: string): boolean => {
  return profanityFilter.isProfane(content)
}

// Channel name validation
export const channelNameSchema = z.string()
  .min(1, 'Channel name is required')
  .max(50, 'Channel name is too long (max 50 characters)')
  .regex(/^[a-zA-Z0-9\-_\s]+$/, 'Channel name can only contain letters, numbers, spaces, hyphens and underscores')
  .trim()

// Join code validation
export const joinCodeSchema = z.string()
  .length(5, 'Join code must be 5 characters')
  .regex(/^[A-Z0-9]+$/, 'Invalid join code format')
  .trim()

// Validate image URLs to prevent XSS attacks via javascript: or data: URIs
export const isValidImageUrl = (url: string): boolean => {
  try {
    const parsed = new URL(url)
    return ['http:', 'https:'].includes(parsed.protocol)
  } catch {
    return false
  }
}
